import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default function PerformerClosureAccess(): JSX.Element;
//# sourceMappingURL=PerformerCloserAccess.d.ts.map