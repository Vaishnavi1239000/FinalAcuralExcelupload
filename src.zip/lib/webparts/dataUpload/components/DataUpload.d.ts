import './Site.scss';
import { IDataUploadProps } from './IDataUploadProps';
export default function AccrualSheet(props: IDataUploadProps): JSX.Element;
//# sourceMappingURL=DataUpload.d.ts.map