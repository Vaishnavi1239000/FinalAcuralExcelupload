import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/site-groups/web";
import "@pnp/sp/site-groups";
import "@pnp/sp/site-users/web";
import { IDataUploadProps } from "./IDataUploadProps";
export default function ManageAccess(props: IDataUploadProps): JSX.Element;
//# sourceMappingURL=ManageAccess.d.ts.map