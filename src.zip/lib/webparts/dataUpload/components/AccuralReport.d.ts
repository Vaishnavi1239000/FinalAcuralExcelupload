import "../components/Site.scss";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default function AccuralReport(): JSX.Element;
//# sourceMappingURL=AccuralReport.d.ts.map