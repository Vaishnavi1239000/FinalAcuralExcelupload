import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
export default function AdjustmentReport(): JSX.Element;
//# sourceMappingURL=AdjustmentReport.d.ts.map