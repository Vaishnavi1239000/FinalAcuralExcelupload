import "./UploadAccrual.scss";
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import "@pnp/sp/folders";
export default function UploadAccrual(): JSX.Element;
//# sourceMappingURL=UploadAccrual.d.ts.map