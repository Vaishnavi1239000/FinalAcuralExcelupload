"use strict";
self["webpackHotUpdate_00721a31_1a24_405c_ada4_55b68b4455e1_0_0_1"]("data-upload-web-part",{

/***/ 563:
/*!****************************************************************!*\
  !*** ./lib/webparts/dataUpload/components/AdjustmentReport.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ AdjustmentReport)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! tslib */ 10196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 85959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../DataUploadWebPart */ 49887);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! xlsx */ 3959);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! file-saver */ 66790);
/* harmony import */ var file_saver__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(file_saver__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_LeftArrow_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../assets/LeftArrow.png */ 3741);
/* harmony import */ var _assets_RightArrow_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../assets/RightArrow.png */ 19734);
/* harmony import */ var _pnp_sp_webs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @pnp/sp/webs */ 47339);
/* harmony import */ var _pnp_sp_lists__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @pnp/sp/lists */ 52185);
/* harmony import */ var _pnp_sp_items__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @pnp/sp/items */ 95324);











function AdjustmentReport() {
    var _this = this;
    var _a = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), isPerformer = _a[0], setIsPerformer = _a[1];
    var _b = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), file = _b[0], setFile = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), data = _c[0], setData = _c[1];
    var _d = react__WEBPACK_IMPORTED_MODULE_0__.useState(false), isSearched = _d[0], setIsSearched = _d[1];
    var _e = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), closedMonths = _e[0], setClosedMonths = _e[1];
    var _f = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), userName = _f[0], setUserName = _f[1];
    var _g = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), department = _g[0], setDepartment = _g[1];
    var _h = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), vendorName = _h[0], setVendorName = _h[1];
    var _j = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), poNumber = _j[0], setPoNumber = _j[1];
    var _k = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), fromDate = _k[0], setFromDate = _k[1];
    var _l = react__WEBPACK_IMPORTED_MODULE_0__.useState(""), toDate = _l[0], setToDate = _l[1];
    var _m = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), userOptions = _m[0], setUserOptions = _m[1];
    var _o = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), deptOptions = _o[0], setDeptOptions = _o[1];
    var _p = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), vendorOptions = _p[0], setVendorOptions = _p[1];
    var _q = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), poOptions = _q[0], setPoOptions = _q[1];
    var _r = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)([]), filteredData = _r[0], setFilteredData = _r[1];
    // Pagination
    var itemsPerPage = 10;
    var _s = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1), currentPage = _s[0], setCurrentPage = _s[1];
    var totalPages = Math.ceil(data.length / itemsPerPage);
    //const totalPages = Math.ceil(filteredData.length / itemsPerPage);
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
    };
    var removeNewRow = function (index) {
        var updated = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__spreadArray)([], data, true);
        updated.splice(index, 1); // remove row by index
        setData(updated);
    };
    var getClosureData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var items;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                        .getByTitle("PerformerClosureAccess")
                        .items.select("Month", "DateofClosure")
                        .top(5000)()];
                case 1:
                    items = _a.sent();
                    return [2 /*return*/, items.map(function (item) {
                            var _a;
                            return ({
                                month: (_a = item.Month) === null || _a === void 0 ? void 0 : _a.toLowerCase(),
                                closingDate: new Date(item.DateofClosure),
                            });
                        })];
            }
        });
    }); };
    var getClosedMonths = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var items;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                        .getByTitle("PerformerClosureAccess")
                        .items.select("Month", "DateofClosure")
                        .top(5000)()];
                case 1:
                    items = _a.sent();
                    // ✅ Store Month + Year
                    return [2 /*return*/, items.map(function (i) {
                            var month = String(i.Month || "").trim().toLowerCase();
                            var year = i.DateofClosure
                                ? new Date(i.DateofClosure).getFullYear()
                                : "";
                            return "".concat(month, "-").concat(year);
                        })];
            }
        });
    }); };
    var searchData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var filter, to, query, items, closedItems, closedMonths_1, formatMonth_1, filteredData_1, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    filter = [];
                    // ✅ Hide deleted
                    filter.push("DeleteFlag ne 1");
                    // ✅ Only Pending
                    filter.push("(Status eq 'Pending' or Status eq 'pending')");
                    // ✅ Text filters
                    if (userName)
                        filter.push("substringof('".concat(userName, "', Username)"));
                    if (department)
                        filter.push("substringof('".concat(department, "', Department)"));
                    if (vendorName)
                        filter.push("substringof('".concat(vendorName, "', VendorName)"));
                    if (poNumber)
                        filter.push("substringof('".concat(poNumber, "', PONumber)"));
                    // ✅ Date filters
                    if (fromDate) {
                        filter.push("Created ge datetime'".concat(new Date(fromDate).toISOString(), "'"));
                    }
                    if (toDate) {
                        to = new Date(toDate);
                        to.setDate(to.getDate() + 1);
                        filter.push("Created lt datetime'".concat(to.toISOString(), "'"));
                    }
                    query = filter.join(" and ");
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.filter(query)
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    console.log("All Items:", items);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("PerformerClosureAccess")
                            .items.select("Month")
                            .top(5000)()];
                case 3:
                    closedItems = _a.sent();
                    closedMonths_1 = closedItems.map(function (i) {
                        var month = String(i.Month || "").trim().toLowerCase();
                        var year = new Date(i.DateofClosure).getFullYear(); // 👈 IMPORTANT
                        return "".concat(month, "-").concat(year);
                    });
                    formatMonth_1 = function (value) {
                        if (!value)
                            return "";
                        var str = String(value).trim().toLowerCase();
                        return str.charAt(0).toUpperCase() + str.slice(1);
                    };
                    filteredData_1 = items
                        .filter(function (item) {
                        var month = String(item.ExpenseMonth || "")
                            .trim()
                            .toLowerCase();
                        var status = String(item.Status || "")
                            .trim()
                            .toLowerCase();
                        // ✅ Ensure pending
                        if (status !== "pending")
                            return false;
                        // ❌ Hide if month is in closure list
                        if (closedMonths_1.includes(month))
                            return false;
                        return true;
                    })
                        .map(function (item) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)({}, item), { ExpenseMonth: formatMonth_1(item.ExpenseMonth) })); });
                    console.log("Final Data:", filteredData_1);
                    setIsSearched(true);
                    setData(filteredData_1);
                    setFilteredData(filteredData_1); // ✅ important for pagination
                    return [3 /*break*/, 5];
                case 4:
                    error_1 = _a.sent();
                    console.error("Search Error:", error_1);
                    alert("Error fetching data");
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var searchData1 = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var filter, to, query, items, closedItems, closedMonths_2, formatMonth_2, filteredData_2, error_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    debugger;
                    filter = [];
                    // ✅ Default filters
                    filter.push("DeleteFlag ne 1");
                    // ✅ SAFE STATUS FILTER (important fix)
                    filter.push("(Status eq 'Pending' or Status eq 'pending')");
                    // ✅ Text filters
                    if (userName && userName.trim() !== "") {
                        filter.push("substringof('".concat(userName.trim(), "', Username)"));
                    }
                    if (department && department.trim() !== "") {
                        filter.push("substringof('".concat(department.trim(), "', Department)"));
                    }
                    if (vendorName && vendorName.trim() !== "") {
                        filter.push("substringof('".concat(vendorName.trim(), "', VendorName)"));
                    }
                    if (poNumber && poNumber.trim() !== "") {
                        filter.push("substringof('".concat(poNumber.trim(), "', PONumber)"));
                    }
                    // ✅ Date filters (FIXED)
                    if (fromDate && !isNaN(new Date(fromDate).getTime())) {
                        filter.push("Created ge datetime'".concat(new Date(fromDate).toISOString(), "'"));
                    }
                    if (toDate && !isNaN(new Date(toDate).getTime())) {
                        to = new Date(toDate);
                        to.setDate(to.getDate() + 1); // ✅ IMPORTANT FIX
                        filter.push("Created lt datetime'".concat(to.toISOString(), "'"));
                    }
                    query = filter.join(" and ");
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.filter(query)
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    console.log("All Items:", items);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("PerformerClosureAccess")
                            .items.select("Month")
                            .top(5000)()];
                case 3:
                    closedItems = _a.sent();
                    closedMonths_2 = closedItems.map(function (i) {
                        return String(i.Month || "")
                            .trim()
                            .toLowerCase();
                    });
                    console.log("Closed Months:", closedMonths_2);
                    formatMonth_2 = function (value) {
                        if (!value)
                            return "";
                        var str = String(value).trim().toLowerCase();
                        return str.charAt(0).toUpperCase() + str.slice(1);
                    };
                    filteredData_2 = items
                        .filter(function (item) {
                        var month = String(item.ExpenseMonth || "")
                            .trim()
                            .toLowerCase();
                        var status = String(item.Status || "")
                            .trim()
                            .toLowerCase();
                        console.log("Checking → Month:", month, "Status:", status);
                        // ✅ Ensure pending
                        if (status !== "pending")
                            return false;
                        // ❌ Hide closed months ONLY
                        return !closedMonths_2.includes(month);
                    })
                        .map(function (item) { return ((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)({}, item), { ExpenseMonth: formatMonth_2(item.ExpenseMonth) })); });
                    console.log("Final Data:", filteredData_2);
                    // ✅ SET DATA
                    setIsSearched(true);
                    setData(filteredData_2);
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _a.sent();
                    console.error("Search Error:", error_2);
                    alert("Error fetching data");
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var formatMonth = function (value) {
        if (!value)
            return "";
        // If it's a valid date → convert to month name
        var date = new Date(value);
        if (!isNaN(date.getTime())) {
            return date.toLocaleString("en-US", { month: "long" });
        }
        // If already string → capitalize properly
        var str = String(value).trim().toLowerCase();
        return str.charAt(0).toUpperCase() + str.slice(1);
    };
    var saveAllRows = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var newRows, getMonthNumber, today, currentMonth, currentYear, currentDate, skippedUsers, _i, newRows_1, item, username, expenseMonthStr, expMonth, expYear, isValid, prevMonth, prevYear, uniqueSkippedUsers, error_3;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    newRows = data.filter(function (item) { return item.Id === 0; });
                    if (newRows.length === 0) {
                        alert("No new rows to save");
                        return [2 /*return*/];
                    }
                    getMonthNumber = function (monthName) {
                        var months = {
                            january: 0,
                            february: 1,
                            march: 2,
                            april: 3,
                            may: 4,
                            june: 5,
                            july: 6,
                            august: 7,
                            september: 8,
                            october: 9,
                            november: 10,
                            december: 11,
                        };
                        return months[monthName.toLowerCase()];
                    };
                    today = new Date();
                    currentMonth = today.getMonth();
                    currentYear = today.getFullYear();
                    currentDate = today.getDate();
                    skippedUsers = [];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 6, , 7]);
                    _i = 0, newRows_1 = newRows;
                    _a.label = 2;
                case 2:
                    if (!(_i < newRows_1.length)) return [3 /*break*/, 5];
                    item = newRows_1[_i];
                    username = item.Username || "Unknown";
                    // ✅ Required validation
                    if (!item.Username ||
                        !item.Department ||
                        !item.VendorName ||
                        !item.VendorCode ||
                        !item.PONumber ||
                        !item.GLCode ||
                        !item.GLDescription ||
                        !item.EmployeeCostCenter ||
                        !item.EmployeeCostCenterName ||
                        !item.Amount ||
                        !item.ExpenseMonth ||
                        !item.Remarks) {
                        alert("All fields are mandatory");
                        return [2 /*return*/];
                    }
                    // ✅ Amount validation
                    if (isNaN(Number(item.Amount))) {
                        alert("Amount must be numeric");
                        return [2 /*return*/];
                    }
                    expenseMonthStr = String(item.ExpenseMonth).trim().toLowerCase();
                    expMonth = getMonthNumber(expenseMonthStr);
                    if (expMonth === undefined) {
                        skippedUsers.push(username);
                        return [3 /*break*/, 4];
                    }
                    expYear = currentYear;
                    isValid = false;
                    // ✅ Current month
                    if (expMonth === currentMonth) {
                        isValid = true;
                    }
                    prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
                    prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
                    if (expMonth === prevMonth &&
                        expYear === prevYear &&
                        currentDate <= 5) {
                        isValid = true;
                    }
                    // ✅ NEW: Allow future months
                    if (expMonth > currentMonth) {
                        isValid = true;
                    }
                    // ❌ Skip invalid
                    if (!isValid) {
                        skippedUsers.push(username);
                        return [3 /*break*/, 4];
                    }
                    // ✅ Insert
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists.getByTitle("AccrualSheetList").items.add({
                            Username: item.Username,
                            Department: item.Department,
                            VendorName: item.VendorName,
                            VendorCode: item.VendorCode,
                            PONumber: item.PONumber,
                            GLCode: item.GLCode,
                            GLDescription: item.GLDescription,
                            EmployeeCostCenter: item.EmployeeCostCenter,
                            EmployeeCostCenterName: item.EmployeeCostCenterName,
                            Amount: Number(item.Amount),
                            ExpenseMonth: expenseMonthStr,
                            Remarks: item.Remarks,
                            DeleteFlag: false,
                            Status: "Pending",
                        })];
                case 3:
                    // ✅ Insert
                    _a.sent();
                    _a.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5:
                    uniqueSkippedUsers = skippedUsers.filter(function (item, index) {
                        return skippedUsers.indexOf(item) === index;
                    });
                    // ✅ Final message
                    if (uniqueSkippedUsers.length > 0) {
                        alert("Upload complete \u2705\nSkipped users: ".concat(uniqueSkippedUsers.join(", ")));
                    }
                    else {
                        alert("All records saved successfully ✅");
                    }
                    void searchData();
                    return [3 /*break*/, 7];
                case 6:
                    error_3 = _a.sent();
                    console.log("Bulk save error:", error_3);
                    alert("Error saving records");
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    // SEARCH DATA
    var loadDropdownData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var items, unique, error_4;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.select("Username", "Department", "VendorName", "PONumber")
                            .top(5000)()];
                case 1:
                    items = _a.sent();
                    unique = function (arr, key) {
                        var result = [];
                        arr.forEach(function (item) {
                            var value = item[key];
                            if (value && result.indexOf(value) === -1) {
                                result.push(value);
                            }
                        });
                        return result;
                    };
                    setUserOptions(unique(items, "Username"));
                    setDeptOptions(unique(items, "Department"));
                    setVendorOptions(unique(items, "VendorName"));
                    setPoOptions(unique(items, "PONumber"));
                    return [3 /*break*/, 3];
                case 2:
                    error_4 = _a.sent();
                    console.log("Dropdown load error:", error_4);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var freezeData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var pendingItems, _i, pendingItems_1, item, error_5;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (data.length === 0) {
                        alert("No records to freeze");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 6, , 7]);
                    pendingItems = data.filter(function (item) { return item.Status === "Pending"; });
                    if (pendingItems.length === 0) {
                        alert("No Pending records found");
                        return [2 /*return*/];
                    }
                    _i = 0, pendingItems_1 = pendingItems;
                    _a.label = 2;
                case 2:
                    if (!(_i < pendingItems_1.length)) return [3 /*break*/, 5];
                    item = pendingItems_1[_i];
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.getById(item.Id)
                            .update({
                            Status: "Freez",
                        })];
                case 3:
                    _a.sent();
                    _a.label = 4;
                case 4:
                    _i++;
                    return [3 /*break*/, 2];
                case 5:
                    alert("Records freeze successfully ✅");
                    // 🔄 Refresh data
                    void searchData(); // or your fetch function
                    return [3 /*break*/, 7];
                case 6:
                    error_5 = _a.sent();
                    console.log("Freeze error:", error_5);
                    alert("Error freezing records");
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var updateRow = function (index, field, value) {
        var _a;
        var updated = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__spreadArray)([], data, true);
        updated[index] = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__assign)({}, updated[index]), (_a = {}, _a[field] = value, _a));
        setData(updated);
    };
    var checkUserAccess = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var user, groups, performer, error_6;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.currentUser()];
                case 1:
                    user = _a.sent();
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.siteUsers.getById(user.Id).groups()];
                case 2:
                    groups = _a.sent();
                    performer = groups.some(function (g) { return g.Title === "AccrualPerformer"; });
                    setIsPerformer(performer);
                    return [3 /*break*/, 4];
                case 3:
                    error_6 = _a.sent();
                    console.log("Access check error", error_6);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        void checkUserAccess();
        void loadDropdownData();
        void getClosedMonths(); // 👈 ADD THIS
    }, []);
    var exportExcel = function () {
        var exportData = data.map(function (item) { return ({
            UserName: item.Username,
            Department: item.Department,
            VendorName: item.VendorName,
            VendorCode: item.VendorCode,
            PONumber: item.PONumber,
            GLCode: item.GLCode,
            GLDescription: item.GLDescription,
            EmployeeCostCenter: item.EmployeeCostCenter,
            EmployeeCostCenterName: item.EmployeeCostCenterName,
            Amount: item.Amount,
            ExpenseMonth: item.ExpenseMonth,
            Remarks: item.Remarks,
        }); });
        var worksheet = xlsx__WEBPACK_IMPORTED_MODULE_9__.utils.json_to_sheet(exportData);
        var workbook = {
            Sheets: { "Accrual Report": worksheet },
            SheetNames: ["Accrual Report"],
        };
        var excelBuffer = xlsx__WEBPACK_IMPORTED_MODULE_9__.write(workbook, {
            bookType: "xlsx",
            type: "array",
        });
        var blob = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        (0,file_saver__WEBPACK_IMPORTED_MODULE_2__.saveAs)(blob, "Accrual_Report.xlsx");
    };
    // DELETE ROW
    var deleteItem = function (id) { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        var confirmDelete, error_7;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    confirmDelete = window.confirm("Are you sure you want to delete the data?");
                    // ❌ If user clicks Cancel → stop
                    if (!confirmDelete) {
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.getById(id)
                            .update({
                            DeleteFlag: true,
                        })];
                case 2:
                    _a.sent();
                    // ✅ Success message
                    alert("Data deleted successfully");
                    void searchData();
                    return [3 /*break*/, 4];
                case 3:
                    error_7 = _a.sent();
                    console.log("Delete error:", error_7);
                    alert("Error deleting data");
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var addNewRow = function () {
        var newRow = {
            Id: 0,
            Username: "",
            Department: "",
            VendorName: "",
            VendorCode: "",
            PONumber: "",
            GLCode: "",
            GLDescription: "",
            EmployeeCostCenter: "",
            EmployeeCostCenterName: "",
            Amount: 0,
            ExpenseMonth: "",
            Remarks: "",
        };
        var updated = (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__spreadArray)((0,tslib__WEBPACK_IMPORTED_MODULE_8__.__spreadArray)([], data, true), [newRow], false);
        setData(updated);
        // Move to last page
        setCurrentPage(Math.ceil(updated.length / itemsPerPage));
    };
    var saveRow = function (item) { return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__awaiter)(_this, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_8__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    // Validation
                    if (!item.Username ||
                        !item.Department ||
                        !item.VendorName ||
                        !item.VendorCode ||
                        !item.PONumber ||
                        !item.GLCode ||
                        !item.GLDescription ||
                        !item.EmployeeCostCenter ||
                        !item.EmployeeCostCenterName ||
                        !item.Amount ||
                        !item.ExpenseMonth ||
                        !item.Remarks) {
                        alert("All fields are mandatory");
                        return [2 /*return*/];
                    }
                    if (isNaN(item.Amount)) {
                        alert("Amount must be numeric");
                        return [2 /*return*/];
                    }
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_1__.sp.web.lists.getByTitle("AccrualSheetList").items.add({
                            Username: item.Username,
                            Department: item.Department,
                            VendorName: item.VendorName,
                            VendorCode: item.VendorCode,
                            PONumber: item.PONumber,
                            GLCode: item.GLCode,
                            GLDescription: item.GLDescription,
                            EmployeeCostCenter: item.EmployeeCostCenter,
                            EmployeeCostCenterName: item.EmployeeCostCenterName,
                            Amount: item.Amount,
                            ExpenseMonth: item.ExpenseMonth,
                            Remarks: item.Remarks,
                            DeleteFlag: false,
                            Status: "Pending",
                        })];
                case 1:
                    _a.sent();
                    alert("Record Saved Successfully");
                    void searchData();
                    return [2 /*return*/];
            }
        });
    }); };
    var Reset = function () {
        setUserName("");
        setDepartment("");
        setVendorName("");
        setPoNumber("");
        setFromDate("");
        setToDate("");
        setData([]);
        setIsSearched(false);
    };
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    // const sortedData = [...filteredData].sort((a, b) => b.Id - a.Id);
    var paginatedData = data.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "header" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Adjustment Report")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "PaddAll" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { display: "flex", gap: "10px", marginBottom: "20px" } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { value: userName, className: "form-control", onChange: function (e) { return setUserName(e.target.value); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: "" }, "All Users"),
                    userOptions.map(function (u, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: i, value: u }, u)); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { value: department, className: "form-control", onChange: function (e) { return setDepartment(e.target.value); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: "" }, "All Departments"),
                    deptOptions.map(function (d, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: i, value: d }, d)); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { value: vendorName, className: "form-control", onChange: function (e) { return setVendorName(e.target.value); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: "" }, "All Vendors"),
                    vendorOptions.map(function (v, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: i, value: v }, v)); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("select", { value: poNumber, className: "form-control", onChange: function (e) { return setPoNumber(e.target.value); } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { value: "" }, "All PO"),
                    poOptions.map(function (p, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("option", { key: i, value: p }, p)); })),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "date", className: "form-control", value: fromDate, onChange: function (e) { return setFromDate(e.target.value); } }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "date", className: "form-control", value: toDate, onChange: function (e) { return setToDate(e.target.value); } })),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "", style: {
                    display: "block",
                    marginBottom: "20px",
                    textAlign: "center",
                } },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: searchData, className: "submit-btn" }, "Search"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: exportExcel, className: "sendback-btn" }, "Export"),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: Reset, className: "reset-btn" }, "Reset")),
            isSearched && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "overflow-x-auto" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "table-vert-scroll" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "UserName"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Department"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Vendor Name"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Vendor Code"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "PO Number"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "GL Code"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "GL Description"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Employee Cost Center"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Employee Cost Center Name"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Amount"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Expense Month"),
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { className: "px-4 py-2" }, "Remarks"),
                                isPerformer && react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Delete"),
                                isPerformer && react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", null, "Action"))),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, paginatedData.length === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { colSpan: 14, style: { textAlign: "center" } }, "No Records Found"))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                            paginatedData.map(function (item, index) {
                                var actualIndex = (currentPage - 1) * itemsPerPage + index;
                                return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: item.Id || actualIndex },
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.Username, onChange: function (e) {
                                            return updateRow(actualIndex, "Username", e.target.value);
                                        } })) : (item.Username)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.Department, onChange: function (e) {
                                            return updateRow(actualIndex, "Department", e.target.value);
                                        } })) : (item.Department)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.VendorName, onChange: function (e) {
                                            return updateRow(actualIndex, "VendorName", e.target.value);
                                        } })) : (item.VendorName)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.VendorCode, onChange: function (e) {
                                            return updateRow(actualIndex, "VendorCode", e.target.value);
                                        } })) : (item.VendorCode)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.PONumber, onChange: function (e) {
                                            return updateRow(actualIndex, "PONumber", e.target.value);
                                        } })) : (item.PONumber)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.GLCode, onChange: function (e) {
                                            return updateRow(actualIndex, "GLCode", e.target.value);
                                        } })) : (item.GLCode)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.GLDescription, onChange: function (e) {
                                            return updateRow(actualIndex, "GLDescription", e.target.value);
                                        } })) : (item.GLDescription)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.EmployeeCostCenter, onChange: function (e) {
                                            return updateRow(actualIndex, "EmployeeCostCenter", e.target.value);
                                        } })) : (item.EmployeeCostCenter)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.EmployeeCostCenterName, onChange: function (e) {
                                            return updateRow(actualIndex, "EmployeeCostCenterName", e.target.value);
                                        } })) : (item.EmployeeCostCenterName)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "number", value: item.Amount, onChange: function (e) {
                                                return updateRow(actualIndex, "Amount", Number(e.target.value));
                                            } })),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.ExpenseMonth, onChange: function (e) {
                                            return updateRow(actualIndex, "ExpenseMonth", e.target.value);
                                        } })) : (formatMonth(item.ExpenseMonth))),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: item.Remarks, onChange: function (e) {
                                            return updateRow(actualIndex, "Remarks", e.target.value);
                                        } })) : (item.Remarks)),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null, item.Id === 0 ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { style: { color: "orange" }, onClick: function () { return removeNewRow(actualIndex); } }, "Remove")) : (isPerformer && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { style: { color: "red" }, onClick: function () { return deleteItem(item.Id); } }, "Delete"))))));
                            }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null,
                                react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { colSpan: 12 }),
                                isPerformer && (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "submit-btn", onClick: addNewRow }, "Add New")),
                                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", null,
                                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: saveAllRows }, "Save All")))))))))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "flex justify-center mt-6 overflow-x-auto" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "flex space-x-2 flex-nowrap px-4 py-2 bg-#2149d5 rounded shadow", style: { textAlign: "end" } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1, style: {
                                backgroundColor: "#fff",
                                border: "1px solid #000 !important",
                                marginRight: "5px",
                                opacity: currentPage === 1 ? 0.5 : 1,
                            }, className: "px-3 py-1 border rounded" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: _assets_LeftArrow_png__WEBPACK_IMPORTED_MODULE_3__, alt: "", width: 15 })),
                        Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                            .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                            .map(function (page) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, style: {
                                backgroundColor: currentPage === page ? "#3c3e45" : "#fff",
                                color: currentPage === page ? "#fff" : "#000",
                                fontWeight: currentPage === page ? "bold" : "normal",
                                margin: currentPage === page ? "5px" : "5px",
                            }, className: "px-3 py-1 border rounded" }, page)); }),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages, style: {
                                backgroundColor: "#fff",
                                border: "1px solid #000 !important",
                                marginLeft: "5px",
                                opacity: currentPage === totalPages ? 0.5 : 1,
                            }, className: "px-3 py-1 border rounded" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: _assets_RightArrow_png__WEBPACK_IMPORTED_MODULE_4__, alt: "", width: 15 })))))),
            isPerformer && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-md-12 col-sm-12", style: { display: "flex", gap: "15px", margin: "0px 10px", alignItems: "center" } },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", null, "Select Excel File"),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "file", accept: ".xlsx", onChange: function (e) {
                                    if (e.target.files && e.target.files.length > 0) {
                                        setFile(e.target.files[0]);
                                    }
                                } })),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "primaryBtn", style: { margin: "0px" }, onClick: freezeData }, "Freeze send to GL")),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: handleExit, className: "Reject-btn" },
                                " ",
                                "Exit",
                                " ")))))))));
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("4f9f4fb11236e10191c0")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=data-upload-web-part.e805c8014fab2b0bf19e.hot-update.js.map