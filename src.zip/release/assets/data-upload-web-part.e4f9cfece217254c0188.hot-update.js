"use strict";
self["webpackHotUpdate_00721a31_1a24_405c_ada4_55b68b4455e1_0_0_1"]("data-upload-web-part",{

/***/ 30990:
/*!*************************************************************!*\
  !*** ./lib/webparts/dataUpload/components/UploadAccrual.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ UploadAccrual)
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! tslib */ 10196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ 85959);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _UploadAccrual_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./UploadAccrual.scss */ 35275);
/* harmony import */ var _microsoft_sp_loader__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-loader */ 58414);
/* harmony import */ var _microsoft_sp_loader__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_loader__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../DataUploadWebPart */ 49887);
/* harmony import */ var _pnp_sp_webs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @pnp/sp/webs */ 47339);
/* harmony import */ var _pnp_sp_site_users_web__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @pnp/sp/site-users/web */ 43500);
/* harmony import */ var _pnp_sp_lists__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @pnp/sp/lists */ 52185);
/* harmony import */ var _pnp_sp_items__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @pnp/sp/items */ 95324);
/* harmony import */ var _pnp_sp_files__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @pnp/sp/files */ 14603);
/* harmony import */ var _pnp_sp_folders__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @pnp/sp/folders */ 79757);
/* harmony import */ var xlsx__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! xlsx */ 3959);












_microsoft_sp_loader__WEBPACK_IMPORTED_MODULE_2__.SPComponentLoader.loadCss('https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css');
function UploadAccrual() {
    var _this = this;
    var _a, _b;
    var _c = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), file = _c[0], setFile = _c[1];
    var _d = react__WEBPACK_IMPORTED_MODULE_0__.useState(null), selectedUser = _d[0], setSelectedUser = _d[1];
    var _e = react__WEBPACK_IMPORTED_MODULE_0__.useState([]), excelData = _e[0], setExcelData = _e[1];
    var _f = react__WEBPACK_IMPORTED_MODULE_0__.useState({}), employee = _f[0], setEmployee = _f[1];
    var normalize = function (str) { return str.trim().toLowerCase(); };
    var requiredColumns = [
        "UserName ",
        "Department ",
        "Vendor Name",
        "Vendor Code ",
        "PO Number",
        "GL Code ",
        "GL Description ",
        "Employee Cost Center ",
        "Employee Cost Center Name ",
        "Amount ",
        "Expense Month ",
        "Remarks (if any)"
    ];
    var validateTemplate = function (data) {
        if (data.length === 0) {
            alert("Uploaded file is empty");
            return false;
        }
        var fileHeaders = Object.keys(data[0]).map(normalize);
        var required = requiredColumns.map(normalize);
        // Check missing columns
        var missing = required.filter(function (col) { return !fileHeaders.includes(col); });
        // Check extra columns
        var extra = fileHeaders.filter(function (col) { return !required.includes(col); });
        if (missing.length > 0) {
            alert("Missing columns: " + missing.join(", "));
            return false;
        }
        if (extra.length > 0) {
            alert("Invalid extra columns: " + extra.join(", "));
            return false;
        }
        return true;
    };
    var handleFileChange = function (e) {
        if (e.target.files && e.target.files.length > 0) {
            var selectedFile = e.target.files[0];
            setFile(selectedFile);
            console.log("Selected file:", selectedFile.name);
        }
        // ✅ Reset input so same file can be selected again
        e.target.value = "";
    };
    var getLoggedInUser = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        var currentUser, email, user, error_1;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    // get logged in user
                    debugger;
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__.sp.web.currentUser()];
                case 1:
                    currentUser = _a.sent();
                    email = currentUser.Email;
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items
                            .select("EmployeeCode", "EmployeeName", "Division", "Location", "EmployeeEmail", "ReportingManager/Title", "HOD/Title", "ContactNo", "EmployeeStatus")
                            .expand("ReportingManager", "HOD")
                            .filter("EmployeeEmail eq '".concat(email, "'"))
                            .top(1)()];
                case 2:
                    user = _a.sent();
                    if (user.length > 0) {
                        setEmployee(user[0]);
                    }
                    console.log(user);
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.log("Error fetching user:", error_1);
                    alert(error_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    react__WEBPACK_IMPORTED_MODULE_0__.useEffect(function () {
        void getLoggedInUser();
    }, []);
    var downloadTemplate = function () {
        // Create empty row with only headers
        var worksheet = xlsx__WEBPACK_IMPORTED_MODULE_11__.utils.json_to_sheet([]);
        // Add headers manually
        xlsx__WEBPACK_IMPORTED_MODULE_11__.utils.sheet_add_aoa(worksheet, [requiredColumns]);
        var workbook = {
            Sheets: { "Template": worksheet },
            SheetNames: ["Template"]
        };
        var excelBuffer = xlsx__WEBPACK_IMPORTED_MODULE_11__.write(workbook, {
            bookType: "xlsx",
            type: "array"
        });
        var blob = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        });
        var fileName = "Accrual_Template.xlsx";
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        link.click();
    };
    var submitData = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        var getMonthNumber, capitalizeMonth, today, currentMonth, currentDate, skippedUsers, i, row, username, _i, requiredColumns_1, col, expenseMonthRaw, expenseMonthStr, expMonth, isValid, prevMonth, uniqueSkipped, error_2;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (excelData.length === 0) {
                        alert("No data to submit");
                        return [2 /*return*/];
                    }
                    getMonthNumber = function (monthName) {
                        var months = {
                            january: 0,
                            february: 1,
                            march: 2,
                            april: 3,
                            may: 4,
                            june: 5,
                            july: 6,
                            august: 7,
                            september: 8,
                            october: 9,
                            november: 10,
                            december: 11
                        };
                        return months[monthName.trim().toLowerCase()];
                    };
                    capitalizeMonth = function (month) {
                        var m = month.trim().toLowerCase();
                        return m.charAt(0).toUpperCase() + m.slice(1);
                    };
                    today = new Date();
                    currentMonth = today.getMonth();
                    currentDate = today.getDate();
                    skippedUsers = [];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 6, , 7]);
                    i = 0;
                    _a.label = 2;
                case 2:
                    if (!(i < excelData.length)) return [3 /*break*/, 5];
                    row = excelData[i];
                    username = String(row["UserName "] || "Unknown");
                    // ✅ Required validation
                    for (_i = 0, requiredColumns_1 = requiredColumns; _i < requiredColumns_1.length; _i++) {
                        col = requiredColumns_1[_i];
                        if (!row[col] || row[col].toString().trim() === "") {
                            alert("Row ".concat(i + 2, ": ").concat(col, " is required"));
                            return [2 /*return*/];
                        }
                    }
                    // ✅ Amount validation
                    if (isNaN(Number(row["Amount "]))) {
                        alert("Row ".concat(i + 2, ": Amount must be numeric"));
                        return [2 /*return*/];
                    }
                    expenseMonthRaw = String(row["Expense Month "] || "");
                    expenseMonthStr = capitalizeMonth(expenseMonthRaw);
                    expMonth = getMonthNumber(expenseMonthStr.toLowerCase());
                    if (expMonth === undefined) {
                        skippedUsers.push(username);
                        return [3 /*break*/, 4];
                    }
                    isValid = false;
                    // ✅ Current month allowed
                    if (expMonth === currentMonth) {
                        isValid = true;
                    }
                    prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
                    if (expMonth === prevMonth && currentDate <= 5) {
                        isValid = true;
                    }
                    // ✅ Future months allowed
                    if (expMonth > currentMonth) {
                        isValid = true;
                    }
                    // ❌ Skip invalid month
                    if (!isValid) {
                        skippedUsers.push(username);
                        return [3 /*break*/, 4];
                    }
                    // ✅ INSERT INTO SHAREPOINT
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.add({
                            Title: username,
                            Username: username,
                            Department: String(row["Department "] || ""),
                            VendorName: String(row["Vendor Name"] || ""),
                            VendorCode: String(row["Vendor Code "] || ""),
                            PONumber: String(row["PO Number"] || ""),
                            GLCode: String(row["GL Code "] || ""),
                            GLDescription: String(row["GL Description "] || ""),
                            EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
                            EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
                            Amount: Number(row["Amount "] || 0),
                            // ✅ FINAL OUTPUT → "April"
                            ExpenseMonth: expenseMonthStr,
                            Remarks: String(row["Remarks (if any)"] || ""),
                            Status: "Pending"
                        })];
                case 3:
                    // ✅ INSERT INTO SHAREPOINT
                    _a.sent();
                    _a.label = 4;
                case 4:
                    i++;
                    return [3 /*break*/, 2];
                case 5:
                    uniqueSkipped = skippedUsers.filter(function (v, i) {
                        return skippedUsers.indexOf(v) === i;
                    });
                    // ✅ Final message
                    if (uniqueSkipped.length > 0) {
                        alert("Data for past months cannot be uploaded \nSkipped (invalid month): ".concat(uniqueSkipped.join(", ")));
                    }
                    else {
                        alert("Accrual details submitted successfully");
                    }
                    // ✅ Reset
                    setExcelData([]);
                    setFile(null);
                    return [3 /*break*/, 7];
                case 6:
                    error_2 = _a.sent();
                    console.log("Error:", error_2);
                    alert("Error saving data");
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    // const submitData = async () => {
    //     if (excelData.length === 0) {
    //         alert("No data to submit");
    //         return;
    //     }
    //     // ✅ Helper: Convert month name to number
    //     const getMonthNumber = (monthName: string) => {
    //         const months: any = {
    //             january: 0,
    //             february: 1,
    //             march: 2,
    //             april: 3,
    //             may: 4,
    //             june: 5,
    //             july: 6,
    //             august: 7,
    //             september: 8,
    //             october: 9,
    //             november: 10,
    //             december: 11
    //         };
    //         return months[monthName.toLowerCase()];
    //     };
    //     const today = new Date();
    //     const currentMonth = today.getMonth();
    //     const currentYear = today.getFullYear();
    //     const currentDate = today.getDate();
    //     let skippedUsers: string[] = [];
    //     try {
    //         for (let i = 0; i < excelData.length; i++) {
    //             const row = excelData[i];
    //             const username = String(row["UserName "] || "Unknown");
    //             // ✅ Required validation
    //             for (const col of requiredColumns) {
    //                 if (!row[col] || row[col].toString().trim() === "") {
    //                     alert(`Row ${i + 2}: ${col} is required`);
    //                     return;
    //                 }
    //             }
    //             // ✅ Amount validation
    //             if (isNaN(Number(row["Amount "]))) {
    //                 alert(`Row ${i + 2}: Amount must be numeric`);
    //                 return;
    //             }
    //             // ✅ Month validation
    //             const expenseMonthStr = String(row["Expense Month "] || "").trim().toLowerCase();
    //             const expMonth = getMonthNumber(expenseMonthStr);
    //             if (expMonth === undefined) {
    //                 skippedUsers.push(username);
    //                 continue;
    //             }
    //             const expYear = currentYear;
    //             let isValid = false;
    //             // ✅ Current month allowed
    //             if (expMonth === currentMonth) {
    //                 isValid = true;
    //             }
    //             // ✅ Previous month allowed only till 5th
    //             const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    //             const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    //             if (
    //                 expMonth === prevMonth &&
    //                 expYear === prevYear &&
    //                 currentDate <= 5
    //             ) {
    //                 isValid = true;
    //             }
    //             // ❌ Skip invalid rows
    //             if (!isValid) {
    //                 skippedUsers.push(username);
    //                 continue;
    //             }
    //             // ✅ Insert valid data
    //             await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items.add({
    //                     Title: username,
    //                     Username: username,
    //                     Department: String(row["Department "] || ""),
    //                     VendorName: String(row["Vendor Name"] || ""),
    //                     VendorCode: String(row["Vendor Code "] || ""),
    //                     PONumber: String(row["PO Number"] || ""),
    //                     GLCode: String(row["GL Code "] || ""),
    //                     GLDescription: String(row["GL Description "] || ""),
    //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
    //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
    //                     Amount: Number(row["Amount "] || 0),
    //                     ExpenseMonth: expenseMonthStr,
    //                     Remarks: String(row["Remarks (if any)"] || ""),
    //                     Status: "Pending"
    //                 });
    //         }
    //         // ✅ Remove duplicate usernames in message
    //         const uniqueSkippedUsers = skippedUsers.filter((item, index) => {
    //             return skippedUsers.indexOf(item) === index;
    //         });
    //         // ✅ Final message
    //         if (uniqueSkippedUsers.length > 0) {
    //             alert(`Upload complete ✅\nSkipped users (invalid month): ${uniqueSkippedUsers.join(", ")}`);
    //         } else {
    //             alert("Data saved successfully");
    //         }
    //         // ✅ Reset
    //         setExcelData([]);
    //         setFile(null);
    //     } catch (error) {
    //         console.log("Save error:", error);
    //         alert("Error saving data");
    //     }
    // };
    // const submitData = async () => {
    //     if (excelData.length === 0) {
    //         alert("No data to submit");
    //         return;
    //     }
    //     // Validate rows
    //     for (let i = 0; i < excelData.length; i++) {
    //         const row = excelData[i];
    //         // Check required fields
    //         for (const col of requiredColumns) {
    //             if (!row[col] || row[col].toString().trim() === "") {
    //                 alert(`Row ${i + 2}: ${col} is required`);
    //                 return;
    //             }
    //         }
    //         // Validate Amount numeric
    //         if (isNaN(Number(row["Amount "]))) {
    //             alert(`Row ${i + 2}: Amount must be numeric`);
    //             return;
    //         }
    //     }
    //     try {
    //         for (const row of excelData) {
    //             const username = String(row["UserName "] || "");
    //             const poNumber = String(row["PO Number"] || "");
    //             const expenseMonth = String(row["Expense Month "] || "");
    //             // Duplicate check
    //             const existingItems = await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items
    //                 .filter(`Username eq '${username}' and PONumber eq '${poNumber}' and ExpenseMonth eq '${expenseMonth}'`)
    //                 .top(1)();
    //             if (existingItems.length > 0) {
    //                 const item = existingItems[0];
    //                 // If record was soft deleted
    //                 if (item.DeleteFlag === true) {
    //                     // Delete old record permanently
    //                     await sp.web.lists
    //                         .getByTitle("AccrualSheetList")
    //                         .items
    //                         .getById(item.Id)
    //                         .delete();
    //                 } else {
    //                     console.log("Duplicate skipped:", username, poNumber);
    //                     continue;   // skip saving
    //                 }
    //             }
    //             if (existingItems.length > 0) {
    //                 console.log("Duplicate skipped:", username, poNumber);
    //                 continue;
    //             }
    //             await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items.add({
    //                     Title: username,
    //                     Username: username,
    //                     Department: String(row["Department "] || ""),
    //                     VendorName: String(row["Vendor Name"] || ""),
    //                     VendorCode: String(row["Vendor Code "] || ""),
    //                     PONumber: poNumber,
    //                     GLCode: String(row["GL Code "] || ""),
    //                     GLDescription: String(row["GL Description "] || ""),
    //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
    //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
    //                     Amount: Number(row["Amount "] || 0),
    //                     ExpenseMonth: expenseMonth,
    //                     Remarks: String(row["Remarks (if any)"] || ""),
    //                     Status: "Pending"
    //                 });
    //         }
    //         alert("Data saved successfully");
    //         // ✅ Clear states
    //         setExcelData([]);
    //         setFile(null);
    //         // ✅ Reload your data (if you have a function like this)
    //       // await  getAllData(); // or whatever function you use to fetch list
    //     } catch (error) {
    //         console.log("Save error:", error);
    //         alert("Error saving data");
    //     }
    // };
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
    };
    var exitPage = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            // setExcelData([]);
            // setFile(null);
            // await getLoggedInUser(); // reload data
            window.location.href = "".concat(window.location.origin, "/sites/SonaFinance/SitePages/Accuralsheet.aspx");
            return [2 /*return*/];
        });
    }); };
    var Resetpage = function () {
        setExcelData([]);
        setFile(null);
        // await getLoggedInUser(); // reload data
    };
    //   const exitPage = () => {
    //   setExcelData([]);
    //   setFile(null);
    //   await getLoggedInUser(); 
    //   //setPage("home"); // ✅ Redirect to home
    // };
    var downloadTemplate1 = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        var files, error_3;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__.sp.web.lists
                            .getByTitle("Accrualtemplate")
                            .items
                            .select("FileRef", "FileLeafRef", "Modified")
                            .orderBy("Modified", false) // false = descending (latest first)
                            .top(1)()];
                case 1:
                    files = _a.sent();
                    if (files.length > 0) {
                        window.open(files[0].FileRef, "_blank");
                    }
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.log("Download error:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var uploadFile = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        var fileBuffer, workbook, sheetName, sheet, data, isValid, error_4;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!file) {
                        alert("Please select file");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, file.arrayBuffer()];
                case 2:
                    fileBuffer = _a.sent();
                    workbook = xlsx__WEBPACK_IMPORTED_MODULE_11__.read(fileBuffer, { type: "array" });
                    sheetName = workbook.SheetNames[0];
                    sheet = workbook.Sheets[sheetName];
                    data = xlsx__WEBPACK_IMPORTED_MODULE_11__.utils.sheet_to_json(sheet);
                    isValid = validateTemplate(data);
                    if (!isValid) {
                        setExcelData([]);
                        alert("Invalid template. Please use the correct format.");
                        return [2 /*return*/];
                    }
                    // ✅ Only set data if valid
                    setExcelData(data);
                    alert("File validated and uploaded successfully");
                    return [3 /*break*/, 4];
                case 3:
                    error_4 = _a.sent();
                    console.log("Upload error:", error_4);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var uploadFile1 = function () { return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__awaiter)(_this, void 0, void 0, function () {
        var fileBuffer, fileName, workbook, sheetName, sheet, data, error_5;
        return (0,tslib__WEBPACK_IMPORTED_MODULE_10__.__generator)(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!file) {
                        alert("Please select file");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, file.arrayBuffer()];
                case 2:
                    fileBuffer = _a.sent();
                    fileName = file.name;
                    // Upload to SharePoint
                    return [4 /*yield*/, _DataUploadWebPart__WEBPACK_IMPORTED_MODULE_3__.sp.web
                            .getFolderByServerRelativePath("/sites/SonaFinance/UploadAccuralTemplate")
                            .files.addUsingPath(fileName, fileBuffer, { Overwrite: true })];
                case 3:
                    // Upload to SharePoint
                    _a.sent();
                    alert("File uploaded successfully");
                    workbook = xlsx__WEBPACK_IMPORTED_MODULE_11__.read(fileBuffer, { type: "array" });
                    sheetName = workbook.SheetNames[0];
                    sheet = workbook.Sheets[sheetName];
                    data = xlsx__WEBPACK_IMPORTED_MODULE_11__.utils.sheet_to_json(sheet);
                    setExcelData(data);
                    return [3 /*break*/, 5];
                case 4:
                    error_5 = _a.sent();
                    console.log("Upload error:", error_5);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'header' },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, "Upload Accrual Sheet")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { padding: "10px" } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "heading1" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", null, "Requestor Information")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'main-formcontainer' },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'row mb-20' },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Employee Code", className: 'font' }, "Employee Code"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.EmployeeCode || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Employee Name", className: 'font' }, "Employee Name "),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.EmployeeName || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Employee Email", className: 'font' }, "Employee Email "),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.EmployeeEmail || "", className: 'form-control readonly' }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'row mb-20' },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Contact No", className: 'font' }, "Contact No"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.ContactNo || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Employee Status", className: 'font' }, "Employee Status"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.EmployeeStatus || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Division", className: 'font' }, "Division"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.Division || "", className: 'form-control readonly' }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'row mb-20' },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "Location", className: 'font' }, "Location"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: employee.Location || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "RM", className: 'font' }, "RM"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: ((_a = employee.ReportingManager) === null || _a === void 0 ? void 0 : _a.Title) || "", className: 'form-control readonly' })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: 'col-md-4' },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", { htmlFor: "HOD", className: 'font' }, "HOD"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { value: ((_b = employee.HOD) === null || _b === void 0 ? void 0 : _b.Title) || "", className: 'form-control readonly' }))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "row" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "col-md-12", style: { display: "flex", gap: "15px", margin: "0px 10px", alignItems: "center" } },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("label", null, "Select Excel File"),
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("input", { type: "file", accept: ".xlsx", onChange: handleFileChange }),
                        file && react__WEBPACK_IMPORTED_MODULE_0__.createElement("p", null,
                            "Selected: ",
                            file.name)),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "primaryBtn", onClick: uploadFile }, " Upload Accrual Sheet"))))),
        excelData.length > 0 && (react__WEBPACK_IMPORTED_MODULE_0__.createElement("table", { style: {
                width: "100%",
                borderCollapse: "collapse",
                marginTop: "30px"
            } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("thead", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", null, Object.keys(excelData[0]).map(function (key) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("th", { key: key, style: {
                        border: "1px solid #ccc",
                        padding: "8px",
                        background: "#f3f3f3"
                    } }, key)); }))),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("tbody", null, excelData.map(function (row, index) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("tr", { key: index }, Object.values(row).map(function (value, i) { return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("td", { key: i, style: {
                    border: "1px solid #ccc",
                    padding: "8px"
                } }, value)); }))); })))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { display: "flex", gap: "5px", padding: "8px", justifyContent: "center" } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "submit-btn", onClick: submitData, disabled: excelData.length === 0, style: { opacity: excelData.length === 0 ? 0.5 : 1, cursor: excelData.length === 0 ? "not-allowed" : "pointer" } }, "Submit")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { className: "reset-btn", onClick: Resetpage }, "Reset")),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("button", { onClick: handleExit, className: "Reject-btn" }, " Exit ")))));
}


/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("857825c1a880bb709d83")
/******/ })();
/******/ 
/******/ }
);
//# sourceMappingURL=data-upload-web-part.e4f9cfece217254c0188.hot-update.js.map