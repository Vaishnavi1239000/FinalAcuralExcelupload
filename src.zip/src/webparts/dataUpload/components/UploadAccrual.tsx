import * as React from "react";
import "./UploadAccrual.scss";
import { SPComponentLoader } from "@microsoft/sp-loader";
import { sp } from "../DataUploadWebPart";
import "@pnp/sp/webs";
import "@pnp/sp/site-users/web";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import "@pnp/sp/files";
import "@pnp/sp/folders";
import * as XLSX from "xlsx";

import { IDataUploadProps } from "./IDataUploadProps";

SPComponentLoader.loadCss(
  "https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css",
);

export default function UploadAccrual() {
  const [file, setFile] = React.useState<File | null>(null);
  const [selectedUser, setSelectedUser] = React.useState<any>(null);
  const [excelData, setExcelData] = React.useState<any[]>([]);
const [data, setData] = React.useState<any[]>([]);
const [filteredData, setFilteredData] = React.useState<any[]>([]);
const [isSearched, setIsSearched] = React.useState(false);

  const [employee, setEmployee] = React.useState<any>({});
  const normalize = (str: string) => str.trim().toLowerCase();
  let skippedRows: any[] = [];

  const requiredColumns = [
    "UserName ",
    "Department ",
    "Vendor Name",
    "Vendor Code ",
    "PO Number",
    "GL Code ",
    "GL Description ",
    "Employee Cost Center ",
    "Employee Cost Center Name ",
    "Amount ",
    "Expense Month ",
    "Remarks (if any)",
  ];

  const validateTemplate = (data: any[]) => {
    if (data.length === 0) {
      alert("Uploaded file is empty");
      return false;
    }

    const fileHeaders = Object.keys(data[0]).map(normalize);
    const required = requiredColumns.map(normalize);

    // Check missing columns
    const missing = required.filter((col) => !fileHeaders.includes(col));

    // Check extra columns
    const extra = fileHeaders.filter((col) => !required.includes(col));

    if (missing.length > 0) {
      alert("Missing columns: " + missing.join(", "));
      return false;
    }

    if (extra.length > 0) {
      alert("Invalid extra columns: " + extra.join(", "));
      return false;
    }

    return true;
  };
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selectedFile = e.target.files[0];
      setFile(selectedFile);

      console.log("Selected file:", selectedFile.name);
    }

    // ✅ Reset input so same file can be selected again
    e.target.value = "";
  };

  const getLoggedInUser = async () => {
    try {
      // get logged in user
      debugger;
      const currentUser = await sp.web.currentUser();

      const email = currentUser.Email;

      const user = await sp.web.lists
        .getByTitle("EmployeeMaster")
        .items.select(
          "EmployeeCode",
          "EmployeeName",
          "Division",
          "Location",
          "EmployeeEmail",
          "ReportingManager/Title",
          "HOD/Title",
          "ContactNo",
          "EmployeeStatus",
        )
        .expand("ReportingManager", "HOD")
        .filter(`EmployeeEmail eq '${email}'`)
        .top(1)();

      if (user.length > 0) {
        setEmployee(user[0]);
      }

      console.log(user);
    } catch (error) {
      console.log("Error fetching user:", error);
      alert(error);
    }
  };
  React.useEffect(() => {
    void getLoggedInUser();
  }, []);

  const downloadTemplate = () => {
    // Create empty row with only headers
    const worksheet = XLSX.utils.json_to_sheet([]);

    // Add headers manually
    XLSX.utils.sheet_add_aoa(worksheet, [requiredColumns]);

    const workbook = {
      Sheets: { Template: worksheet },
      SheetNames: ["Template"],
    };

    const excelBuffer = XLSX.write(workbook, {
      bookType: "xlsx",
      type: "array",
    });

    const blob = new Blob([excelBuffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });

    const fileName = "Accrual_Template.xlsx";

    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = fileName;
    link.click();
  };
//   const submitData = async () => {
//     if (excelData.length === 0) {
//       alert("No data to submit");
//       return;
//     }

//     // ✅ Month mapping (for validation logic)
//     const getMonthNumber = (monthName: string) => {
//       const months: any = {
//         january: 0,
//         february: 1,
//         march: 2,
//         april: 3,
//         may: 4,
//         june: 5,
//         july: 6,
//         august: 7,
//         september: 8,
//         october: 9,
//         november: 10,
//         december: 11,
//       };

//       return months[monthName.trim().toLowerCase()];
//     };

//     // ✅ Capitalize Month (FINAL FIX)
//     const capitalizeMonth = (month: string) => {
//       const m = month.trim().toLowerCase();
//       return m.charAt(0).toUpperCase() + m.slice(1);
//     };

//     const today = new Date();
//     const currentMonth = today.getMonth();
//     const currentDate = today.getDate();

//     let skippedUsers: string[] = [];

//     try {
//       for (let i = 0; i < excelData.length; i++) {
//         const row = excelData[i];
//         const username = String(row["UserName "] || "Unknown");

//         // ✅ Required validation
//         for (const col of requiredColumns) {
//           if (!row[col] || row[col].toString().trim() === "") {
//             alert(`Row ${i + 2}: ${col} is required`);
//             return;
//           }
//         }

//         // ✅ Amount validation
//         if (isNaN(Number(row["Amount "]))) {
//           alert(`Row ${i + 2}: Amount must be numeric`);
//           return;
//         }

//         // ✅ Get & format month
//         const expenseMonthRaw = String(row["Expense Month "] || "");
//         const expenseMonthStr = capitalizeMonth(expenseMonthRaw); // 👈 SAVED VALUE (April)

//         const expMonth = getMonthNumber(expenseMonthStr.toLowerCase()); // 👈 LOGIC VALUE

//         if (expMonth === undefined) {
//           skippedUsers.push(username);
//           continue;
//         }

//         let isValid = false;

//         // ✅ Current month allowed
//         if (expMonth === currentMonth) {
//           isValid = true;
//         }

//         // ✅ Previous month till 5th
//         const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;

//         if (expMonth === prevMonth && currentDate <= 5) {
//           isValid = true;
//         }

//         // ✅ Future months allowed
//         if (expMonth > currentMonth) {
//           isValid = true;
//         }

//         // ❌ Skip invalid month
//         if (!isValid) {
//           skippedUsers.push(username);
//           continue;
//         }

//         // ✅ INSERT INTO SHAREPOINT
//         await sp.web.lists.getByTitle("AccrualSheetList").items.add({
//           Title: username,
//           Username: username,
//           Department: String(row["Department "] || ""),
//           VendorName: String(row["Vendor Name"] || ""),
//           VendorCode: String(row["Vendor Code "] || ""),
//           PONumber: String(row["PO Number"] || ""),
//           GLCode: String(row["GL Code "] || ""),
//           GLDescription: String(row["GL Description "] || ""),
//           EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
//           EmployeeCostCenterName: String(
//             row["Employee Cost Center Name "] || "",
//           ),
//           Amount: Number(row["Amount "] || 0),

//           // ✅ FINAL OUTPUT → "April"
//           ExpenseMonth: expenseMonthStr,

//           Remarks: String(row["Remarks (if any)"] || ""),
//           Status: "Pending",
//         });
//       }

//       // ✅ Remove duplicates from skipped users
//       const uniqueSkipped = skippedUsers.filter((v, i) => {
//         return skippedUsers.indexOf(v) === i;
//       });

//       // ✅ Final message
//       if (uniqueSkipped.length > 0) {
//         alert(
//           `Data for past months cannot be uploaded \nSkipped (invalid month): ${uniqueSkipped.join(", ")}`,
//         );
//       } else {
//         alert("Accrual details submitted successfully");
//       }

//       // ✅ Reset
//       setExcelData([]);
//       setFile(null);
//     } catch (error) {
//       console.log("Error:", error);
//       alert("Error saving data");
//     }
//   };

  // const submitData = async () => {

  //     if (excelData.length === 0) {
  //         alert("No data to submit");
  //         return;
  //     }

  //     // ✅ Helper: Convert month name to number
  //     const getMonthNumber = (monthName: string) => {
  //         const months: any = {
  //             january: 0,
  //             february: 1,
  //             march: 2,
  //             april: 3,
  //             may: 4,
  //             june: 5,
  //             july: 6,
  //             august: 7,
  //             september: 8,
  //             october: 9,
  //             november: 10,
  //             december: 11
  //         };
  //         return months[monthName.toLowerCase()];
  //     };

  //     const today = new Date();
  //     const currentMonth = today.getMonth();
  //     const currentYear = today.getFullYear();
  //     const currentDate = today.getDate();

  //     let skippedUsers: string[] = [];

  //     try {

  //         for (let i = 0; i < excelData.length; i++) {

  //             const row = excelData[i];

  //             const username = String(row["UserName "] || "Unknown");

  //             // ✅ Required validation
  //             for (const col of requiredColumns) {
  //                 if (!row[col] || row[col].toString().trim() === "") {
  //                     alert(`Row ${i + 2}: ${col} is required`);
  //                     return;
  //                 }
  //             }

  //             // ✅ Amount validation
  //             if (isNaN(Number(row["Amount "]))) {
  //                 alert(`Row ${i + 2}: Amount must be numeric`);
  //                 return;
  //             }

  //             // ✅ Month validation
  //             const expenseMonthStr = String(row["Expense Month "] || "").trim().toLowerCase();

  //             const expMonth = getMonthNumber(expenseMonthStr);

  //             if (expMonth === undefined) {
  //                 skippedUsers.push(username);
  //                 continue;
  //             }

  //             const expYear = currentYear;

  //             let isValid = false;

  //             // ✅ Current month allowed
  //             if (expMonth === currentMonth) {
  //                 isValid = true;
  //             }

  //             // ✅ Previous month allowed only till 5th
  //             const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
  //             const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;

  //             if (
  //                 expMonth === prevMonth &&
  //                 expYear === prevYear &&
  //                 currentDate <= 5
  //             ) {
  //                 isValid = true;
  //             }

  //             // ❌ Skip invalid rows
  //             if (!isValid) {
  //                 skippedUsers.push(username);
  //                 continue;
  //             }

  //             // ✅ Insert valid data
  //             await sp.web.lists
  //                 .getByTitle("AccrualSheetList")
  //                 .items.add({

  //                     Title: username,
  //                     Username: username,
  //                     Department: String(row["Department "] || ""),
  //                     VendorName: String(row["Vendor Name"] || ""),
  //                     VendorCode: String(row["Vendor Code "] || ""),
  //                     PONumber: String(row["PO Number"] || ""),
  //                     GLCode: String(row["GL Code "] || ""),
  //                     GLDescription: String(row["GL Description "] || ""),
  //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
  //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
  //                     Amount: Number(row["Amount "] || 0),
  //                     ExpenseMonth: expenseMonthStr,
  //                     Remarks: String(row["Remarks (if any)"] || ""),
  //                     Status: "Pending"

  //                 });
  //         }

  //         // ✅ Remove duplicate usernames in message
  //         const uniqueSkippedUsers = skippedUsers.filter((item, index) => {
  //             return skippedUsers.indexOf(item) === index;
  //         });

  //         // ✅ Final message
  //         if (uniqueSkippedUsers.length > 0) {
  //             alert(`Upload complete ✅\nSkipped users (invalid month): ${uniqueSkippedUsers.join(", ")}`);
  //         } else {
  //             alert("Data saved successfully");
  //         }

  //         // ✅ Reset
  //         setExcelData([]);
  //         setFile(null);

  //     } catch (error) {

  //         console.log("Save error:", error);
  //         alert("Error saving data");

  //     }
  // };

  // const submitData = async () => {

  //     if (excelData.length === 0) {
  //         alert("No data to submit");
  //         return;
  //     }

  //     // Validate rows
  //     for (let i = 0; i < excelData.length; i++) {

  //         const row = excelData[i];

  //         // Check required fields
  //         for (const col of requiredColumns) {

  //             if (!row[col] || row[col].toString().trim() === "") {
  //                 alert(`Row ${i + 2}: ${col} is required`);
  //                 return;
  //             }

  //         }

  //         // Validate Amount numeric
  //         if (isNaN(Number(row["Amount "]))) {
  //             alert(`Row ${i + 2}: Amount must be numeric`);
  //             return;
  //         }

  //     }

  //     try {

  //         for (const row of excelData) {

  //             const username = String(row["UserName "] || "");
  //             const poNumber = String(row["PO Number"] || "");
  //             const expenseMonth = String(row["Expense Month "] || "");

  //             // Duplicate check
  //             const existingItems = await sp.web.lists
  //                 .getByTitle("AccrualSheetList")
  //                 .items
  //                 .filter(`Username eq '${username}' and PONumber eq '${poNumber}' and ExpenseMonth eq '${expenseMonth}'`)
  //                 .top(1)();

  //             if (existingItems.length > 0) {

  //                 const item = existingItems[0];

  //                 // If record was soft deleted
  //                 if (item.DeleteFlag === true) {

  //                     // Delete old record permanently
  //                     await sp.web.lists
  //                         .getByTitle("AccrualSheetList")
  //                         .items
  //                         .getById(item.Id)
  //                         .delete();

  //                 } else {

  //                     console.log("Duplicate skipped:", username, poNumber);
  //                     continue;   // skip saving

  //                 }

  //             }

  //             if (existingItems.length > 0) {
  //                 console.log("Duplicate skipped:", username, poNumber);
  //                 continue;
  //             }

  //             await sp.web.lists
  //                 .getByTitle("AccrualSheetList")
  //                 .items.add({

  //                     Title: username,

  //                     Username: username,
  //                     Department: String(row["Department "] || ""),
  //                     VendorName: String(row["Vendor Name"] || ""),
  //                     VendorCode: String(row["Vendor Code "] || ""),
  //                     PONumber: poNumber,
  //                     GLCode: String(row["GL Code "] || ""),
  //                     GLDescription: String(row["GL Description "] || ""),
  //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
  //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
  //                     Amount: Number(row["Amount "] || 0),
  //                     ExpenseMonth: expenseMonth,
  //                     Remarks: String(row["Remarks (if any)"] || ""),
  //                     Status: "Pending"

  //                 });

  //         }

  //         alert("Data saved successfully");

  //         // ✅ Clear states
  //         setExcelData([]);
  //         setFile(null);

  //         // ✅ Reload your data (if you have a function like this)
  //       // await  getAllData(); // or whatever function you use to fetch list

  //     } catch (error) {

  //         console.log("Save error:", error);
  //         alert("Error saving data");

  //     }

  // };
  const submitData = async () => {
  if (excelData.length === 0) {
    alert("No data to submit");
    return;
  }

  const getMonthNumber = (monthName: string) => {
    const months: any = {
      january: 0,
      february: 1,
      march: 2,
      april: 3,
      may: 4,
      june: 5,
      july: 6,
      august: 7,
      september: 8,
      october: 9,
      november: 10,
      december: 11,
    };
    return months[monthName.trim().toLowerCase()];
  };

  const capitalizeMonth = (month: string) => {
    const m = month.trim().toLowerCase();
    return m.charAt(0).toUpperCase() + m.slice(1);
  };

  const today = new Date();
  const currentMonth = today.getMonth();
  const currentDate = today.getDate();

  let skippedUsers: string[] = [];
  let skippedRows: any[] = []; // ✅ STORE FULL ROWS

  try {
    for (let i = 0; i < excelData.length; i++) {
      const row = excelData[i];
      const username = String(row["UserName "] || "Unknown");

      // ✅ Required validation
      for (const col of requiredColumns) {
        if (!row[col] || row[col].toString().trim() === "") {
          alert(`Row ${i + 2}: ${col} is required`);
          return;
        }
      }

      // ✅ Amount validation
      if (isNaN(Number(row["Amount "]))) {
        alert(`Row ${i + 2}: Amount must be numeric`);
        return;
      }

      const expenseMonthRaw = String(row["Expense Month "] || "");
      const expenseMonthStr = capitalizeMonth(expenseMonthRaw);

      const expMonth = getMonthNumber(expenseMonthStr.toLowerCase());

      if (expMonth === undefined) {
        skippedUsers.push(username);

        // ✅ PUSH TO GRID
        skippedRows.push({
          Id: 0,
          Username: username,
          Department: row["Department "] || "",
          VendorName: row["Vendor Name"] || "",
          VendorCode: row["Vendor Code "] || "",
          PONumber: row["PO Number"] || "",
          GLCode: row["GL Code "] || "",
          GLDescription: row["GL Description "] || "",
          EmployeeCostCenter: row["Employee Cost Center "] || "",
          EmployeeCostCenterName: row["Employee Cost Center Name "] || "",
          Amount: Number(row["Amount "] || 0),
          ExpenseMonth: expenseMonthStr,
          Remarks: row["Remarks (if any)"] || "",
        });

        continue;
      }

      let isValid = false;

      // ✅ Current month
      if (expMonth === currentMonth) {
        isValid = true;
      }

      // ✅ Previous month till 5th
      const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;

      if (expMonth === prevMonth && currentDate <= 5) {
        isValid = true;
      }

      // ✅ Future months
      if (expMonth > currentMonth) {
        isValid = true;
      }

      // ❌ Skip past months
      if (!isValid) {
        skippedUsers.push(username);

        // ✅ PUSH TO GRID
        skippedRows.push({
          Id: 0,
          Username: username,
          Department: row["Department "] || "",
          VendorName: row["Vendor Name"] || "",
          VendorCode: row["Vendor Code "] || "",
          PONumber: row["PO Number"] || "",
          GLCode: row["GL Code "] || "",
          GLDescription: row["GL Description "] || "",
          EmployeeCostCenter: row["Employee Cost Center "] || "",
          EmployeeCostCenterName: row["Employee Cost Center Name "] || "",
          Amount: Number(row["Amount "] || 0),
          ExpenseMonth: expenseMonthStr,
          Remarks: row["Remarks (if any)"] || "",
        });

        continue;
      }

      // ✅ SAVE VALID DATA
      await sp.web.lists.getByTitle("AccrualSheetList").items.add({
        Title: username,
        Username: username,
        Department: String(row["Department "] || ""),
        VendorName: String(row["Vendor Name"] || ""),
        VendorCode: String(row["Vendor Code "] || ""),
        PONumber: String(row["PO Number"] || ""),
        GLCode: String(row["GL Code "] || ""),
        GLDescription: String(row["GL Description "] || ""),
        EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
        EmployeeCostCenterName: String(
          row["Employee Cost Center Name "] || ""
        ),
        Amount: Number(row["Amount "] || 0),
        ExpenseMonth: expenseMonthStr,
        Remarks: String(row["Remarks (if any)"] || ""),
        Status: "Pending",
      });
    }

    // ✅ UNIQUE USERS
    const uniqueSkipped = skippedUsers.filter((v, i) => {
      return skippedUsers.indexOf(v) === i;
    });

    // ✅ SHOW MESSAGE
    if (uniqueSkipped.length > 0) {
      alert(
        `Past month data not allowed ❌\nShown in grid for correction:\n${uniqueSkipped.join(", ")}`
      );

      // ✅ SHOW SKIPPED DATA IN GRID
      setData(skippedRows);
      setFilteredData(skippedRows);
      setIsSearched(true);

    } else {
      alert("Accrual details submitted successfully ✅");

      // ✅ CLEAR GRID
      setData([]);
      setFilteredData([]);
      setIsSearched(false);
    }

    setExcelData([]);
    setFile(null);

  } catch (error) {
    console.log("Error:", error);
    alert("Error saving data");
  }
};


  const handleExit = () => {
    //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
    // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
    window.location.href = `https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx`;
  };
  const exitPage = async () => {
    // setExcelData([]);
    // setFile(null);

    // await getLoggedInUser(); // reload data
    window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
  };
  const Resetpage = () => {
    setExcelData([]);
    setFile(null);

    // await getLoggedInUser(); // reload data
  };

  //   const exitPage = () => {
  //   setExcelData([]);
  //   setFile(null);
  //   await getLoggedInUser();
  //   //setPage("home"); // ✅ Redirect to home
  // };

  const downloadTemplate1 = async () => {
    try {
      const files = await sp.web.lists
        .getByTitle("Accrualtemplate")
        .items.select("FileRef", "FileLeafRef", "Modified")
        .orderBy("Modified", false) // false = descending (latest first)
        .top(1)();

      if (files.length > 0) {
        window.open(files[0].FileRef, "_blank");
      }
    } catch (error) {
      console.log("Download error:", error);
    }
  };
  const uploadFile = async () => {
    if (!file) {
      alert("Please select file");
      return;
    }

    try {
      const fileBuffer = await file.arrayBuffer();

      const workbook = XLSX.read(fileBuffer, { type: "array" });

      const sheetName = workbook.SheetNames[0];
      const sheet = workbook.Sheets[sheetName];

      const data = XLSX.utils.sheet_to_json(sheet);

      // ✅ VALIDATE TEMPLATE
      const isValid = validateTemplate(data);

      if (!isValid) {
        setExcelData([]);
        alert("Invalid template. Please use the correct format.");
        return;
      }

      // ✅ Only set data if valid
      setExcelData(data);

      alert("File validated and uploaded successfully");
    } catch (error) {
      console.log("Upload error:", error);
    }
  };

  const uploadFile1 = async () => {
    if (!file) {
      alert("Please select file");
      return;
    }

    try {
      const fileBuffer = await file.arrayBuffer();
      const fileName = file.name;

      // Upload to SharePoint
      await sp.web
        .getFolderByServerRelativePath(
          "/sites/SonaFinance/UploadAccuralTemplate",
        )
        .files.addUsingPath(fileName, fileBuffer, { Overwrite: true });

      alert("File uploaded successfully");

      // Read Excel
      const workbook = XLSX.read(fileBuffer, { type: "array" });

      const sheetName = workbook.SheetNames[0];

      const sheet = workbook.Sheets[sheetName];

      const data = XLSX.utils.sheet_to_json(sheet);

      setExcelData(data);
    } catch (error) {
      console.log("Upload error:", error);
    }
  };

  return (
    <div>
      <div className="header">
        <h1>Upload Accrual Sheet</h1>
      </div>
      <div style={{ padding: "10px" }}>
        <div className="heading1">
          <label>Requestor Information</label>
        </div>
        <div className="main-formcontainer">
          <div className="row mb-20">
            <div className="col-md-4">
              <label htmlFor="Employee Code" className="font">
                Employee Code
              </label>
              <input
                value={employee.EmployeeCode || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="Employee Name" className="font">
                Employee Name{" "}
              </label>
              <input
                value={employee.EmployeeName || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="Employee Email" className="font">
                Employee Email{" "}
              </label>
              <input
                value={employee.EmployeeEmail || ""}
                className="form-control readonly"
              />
            </div>
          </div>
          <div className="row mb-20">
            <div className="col-md-4">
              <label htmlFor="Contact No" className="font">
                Contact No
              </label>
              <input
                value={employee.ContactNo || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="Employee Status" className="font">
                Employee Status
              </label>
              <input
                value={employee.EmployeeStatus || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="Division" className="font">
                Division
              </label>
              <input
                value={employee.Division || ""}
                className="form-control readonly"
              />
            </div>
          </div>
          <div className="row mb-20">
            <div className="col-md-4">
              <label htmlFor="Location" className="font">
                Location
              </label>
              <input
                value={employee.Location || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="RM" className="font">
                RM
              </label>
              <input
                value={employee.ReportingManager?.Title || ""}
                className="form-control readonly"
              />
            </div>
            <div className="col-md-4">
              <label htmlFor="HOD" className="font">
                HOD
              </label>
              <input
                value={employee.HOD?.Title || ""}
                className="form-control readonly"
              />
            </div>
          </div>
        </div>
      </div>
      <div style={{padding:"0px 10px"}}>
        <div className="row">
          <div className="col-md-4">
            <div>
              <button className="primaryBtn" onClick={downloadTemplate}>
                Download Template
              </button>
              <p style={{ color: "red", fontSize: "12px" }}>
                Download the above template to upload the data
              </p>
            </div>
          </div>
        </div>
        <div className="row">
          <div
            className="col-md-12"
            style={{
              display: "flex",
              gap: "15px",
              margin: "0px 10px",
              alignItems: "center",
            }}
          >
            <div>
              <label>Select Excel File</label>
              <input type="file" accept=".xlsx" onChange={handleFileChange} />
              {file && <p>Selected: {file.name}</p>}
            </div>
            <div>
              <button className="primaryBtn" onClick={uploadFile}>
                {" "}
                Upload Accrual Sheet
              </button>
            </div>
          </div>
        </div>
      </div>
      {excelData.length > 0 && (
        <table
          style={{
            width: "100%",
            borderCollapse: "collapse",
            marginTop: "30px",
          }}
        >
          <thead>
            <tr>
              {Object.keys(excelData[0]).map((key) => (
                <th
                  key={key}
                  style={{
                    border: "1px solid #ccc",
                    padding: "8px",
                    background: "#f3f3f3",
                  }}
                >
                  {key}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {excelData.map((row: any, index: number) => (
              <tr key={index}>
                {Object.values(row).map((value: any, i) => (
                  <td
                    key={i}
                    style={{
                      border: "1px solid #ccc",
                      padding: "8px",
                    }}
                  >
                    {value}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div
        style={{
          display: "flex",
          gap: "5px",
          padding: "8px",
          justifyContent: "center",
        }}
      >
        <div>
          <button
            className="submit-btn"
            onClick={submitData}
            disabled={excelData.length === 0}
            style={{
              opacity: excelData.length === 0 ? 0.5 : 1,
              cursor: excelData.length === 0 ? "not-allowed" : "pointer",
            }}
          >
            Submit
          </button>
        </div>
        <div>
          <button className="reset-btn" onClick={Resetpage}>
            Reset
          </button>
        </div>
        <div>
          <button onClick={handleExit} className="Reject-btn">
            {" "}
            Exit{" "}
          </button>
        </div>
      </div>
    </div>
  );
}
