"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AccrualSheet;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
//import styles from './DataUpload.module.scss';
require("./Site.scss");
var ManageAccess_1 = tslib_1.__importDefault(require("./ManageAccess"));
var UploadAccrual_1 = tslib_1.__importDefault(require("./UploadAccrual"));
// import AdjustmentReport from './AdjustmentReport';
var AccuralReport_1 = tslib_1.__importDefault(require("./AccuralReport"));
var AdjustmentReport_1 = tslib_1.__importDefault(require("./AdjustmentReport"));
var DataUploadWebPart_1 = require("../DataUploadWebPart");
var PerformerCloserAccess_1 = tslib_1.__importDefault(require("./PerformerCloserAccess"));
var access_png_1 = tslib_1.__importDefault(require("../assets/access.png"));
var upload_png_1 = tslib_1.__importDefault(require("../assets/upload.png"));
var pie_chart_png_1 = tslib_1.__importDefault(require("../assets/pie-chart.png"));
var line_chart_png_1 = tslib_1.__importDefault(require("../assets/line-chart.png"));
var closure_png_1 = tslib_1.__importDefault(require("../assets/closure.png"));
function AccrualSheet(props) {
    var _this = this;
    var _a = React.useState("home"), page = _a[0], setPage = _a[1];
    var _b = React.useState(null), hasAccess = _b[0], setHasAccess = _b[1];
    var _c = React.useState(false), hasManageAccess = _c[0], setHasManageAccess = _c[1];
    var _d = React.useState(false), isPerformer = _d[0], setIsPerformer = _d[1];
    var _e = React.useState(false), canUpload = _e[0], setCanUpload = _e[1];
    var openUploadPage = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var currentUser_1, today_1, items, access, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    currentUser_1 = _a.sent();
                    today_1 = new Date();
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetAccessList")
                            .items
                            .select("FromDate", "UptoDate", "Username/EMail")
                            .expand("Username")
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    access = items.some(function (item) {
                        var _a;
                        var from = new Date(item.FromDate);
                        var upto = new Date(item.UptoDate);
                        return (((_a = item.Username) === null || _a === void 0 ? void 0 : _a.EMail) === currentUser_1.Email &&
                            today_1 >= from &&
                            today_1 <= upto);
                    });
                    if (access) {
                        setPage("upload");
                    }
                    else {
                        alert("You do not have permission to upload accrual sheet for this period.");
                    }
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.log(error_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var checkManageAccess = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var groups, isManager, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser.groups()];
                case 1:
                    groups = _a.sent();
                    console.log("User Groups:", groups); // 🔍 debug
                    isManager = groups.some(function (group) { return group.Title === "AccrualManagerAccess"; });
                    setHasManageAccess(isManager);
                    return [3 /*break*/, 3];
                case 2:
                    error_2 = _a.sent();
                    console.log(error_2);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var checkUserAccess = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var currentUser_2, today_2, items, access, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    currentUser_2 = _a.sent();
                    today_2 = new Date();
                    today_2.setHours(0, 0, 0, 0); // ✅ remove time
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetAccessList")
                            .items
                            .select("FromDate", "UptoDate", "Username/EMail")
                            .expand("Username")
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    access = items.some(function (item) {
                        var _a;
                        var from = new Date(item.FromDate);
                        var upto = new Date(item.UptoDate);
                        // ✅ remove time from both
                        from.setHours(0, 0, 0, 0);
                        upto.setHours(0, 0, 0, 0);
                        return (((_a = item.Username) === null || _a === void 0 ? void 0 : _a.EMail) === currentUser_2.Email &&
                            today_2 >= from &&
                            today_2 <= upto);
                    });
                    setHasAccess(true);
                    setCanUpload(access);
                    return [3 /*break*/, 4];
                case 3:
                    error_3 = _a.sent();
                    console.log(error_3);
                    setHasAccess(false);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var checkUserAccess1 = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var user, groups, performer, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    user = _a.sent();
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.siteUsers
                            .getById(user.Id)
                            .groups()];
                case 2:
                    groups = _a.sent();
                    performer = groups.some(function (g) { return g.Title === "AccrualPerformer"; });
                    setIsPerformer(performer);
                    return [3 /*break*/, 4];
                case 3:
                    error_4 = _a.sent();
                    console.log("Access check error", error_4);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        void checkUserAccess1();
        void checkUserAccess();
        void checkManageAccess(); // ✅ ADD THIS LINE
    }, []);
    // Loading state
    if (hasAccess === null) {
        return React.createElement("h3", { style: { padding: "30px" } }, "Loading...");
    }
    // No Access
    // if (!hasAccess) {
    //   return (
    //     <div style={{ padding: "40px" }}>
    //       <h2 style={{ color: "red" }}>Access Denied</h2>
    //       <p>You do not have access to this portal.</p>
    //     </div>
    //   );
    // }
    if (page === "manage") {
        return React.createElement(ManageAccess_1.default, tslib_1.__assign({}, props));
    }
    if (page === "upload") {
        return React.createElement(UploadAccrual_1.default, null);
    }
    if (page === "report") {
        return React.createElement(AccuralReport_1.default, null);
    }
    if (page === "report1") {
        return React.createElement(AdjustmentReport_1.default, null);
    }
    if (page === "Clouser") {
        return React.createElement(PerformerCloserAccess_1.default, null);
    }
    return (React.createElement("div", null,
        React.createElement("div", { className: 'headSheet' },
            React.createElement("h2", null, "Accrual Sheet")),
        React.createElement("section", { className: "hero" },
            React.createElement("div", { className: "overlay" }),
            React.createElement("div", { className: "hero-content" },
                React.createElement("div", { className: "card-container" },
                    hasManageAccess && (React.createElement("div", { className: "infoCard", onClick: function () { return setPage("manage"); } },
                        React.createElement("div", { className: "cardContent" },
                            React.createElement("div", { className: 'cardalin' },
                                React.createElement("span", { className: 'boximage' },
                                    React.createElement("img", { src: access_png_1.default, alt: "", width: 25, height: 25 })),
                                React.createElement("h4", null, "Manage Access"))))),
                    canUpload && (React.createElement("div", { className: "infoCard", onClick: function () { return setPage("upload"); } },
                        React.createElement("div", { className: "cardContent" },
                            React.createElement("div", { className: 'cardalin' },
                                React.createElement("span", { className: 'boximage' },
                                    React.createElement("img", { src: upload_png_1.default, alt: "", width: 25, height: 25 })),
                                React.createElement("h4", null, "Upload Sheet"))))),
                    React.createElement("div", { className: "infoCard", onClick: function () { return setPage("report1"); } },
                        React.createElement("div", { className: "cardContent" },
                            React.createElement("div", { className: 'cardalin' },
                                React.createElement("span", { className: 'boximage' },
                                    React.createElement("img", { src: pie_chart_png_1.default, alt: "", width: 25, height: 25 })),
                                React.createElement("h4", null, "Adjustment Report")))),
                    React.createElement("div", { className: "infoCard", onClick: function () { return setPage("report"); } },
                        React.createElement("div", { className: "cardContent" },
                            React.createElement("div", { className: 'cardalin' },
                                React.createElement("span", { className: 'boximage' },
                                    React.createElement("img", { src: line_chart_png_1.default, alt: "", width: 25, height: 25 })),
                                React.createElement("h4", null, "Accrual Report")))),
                    isPerformer && (React.createElement("div", { className: "infoCard", onClick: function () { return setPage("Clouser"); } },
                        React.createElement("div", { className: "cardContent" },
                            React.createElement("div", { className: 'cardalin' },
                                React.createElement("span", { className: 'boximage' },
                                    React.createElement("img", { src: closure_png_1.default, alt: "", width: 25, height: 25 })),
                                React.createElement("h4", null, "Performer Closure"))))))))));
}
//# sourceMappingURL=DataUpload.js.map