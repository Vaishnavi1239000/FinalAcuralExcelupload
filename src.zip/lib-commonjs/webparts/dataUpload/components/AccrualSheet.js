"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AccrualSheet;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./Site.scss");
var ManageAccess_1 = tslib_1.__importDefault(require("./ManageAccess"));
var UploadAccrual_1 = tslib_1.__importDefault(require("./UploadAccrual"));
var DataUploadWebPart_1 = require("../DataUploadWebPart");
function AccrualSheet(props) {
    var _this = this;
    var _a = React.useState("home"), page = _a[0], setPage = _a[1];
    var _b = React.useState(null), hasAccess = _b[0], setHasAccess = _b[1];
    var checkUserAccess = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var user_1, today_1, items, access, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    user_1 = _a.sent();
                    today_1 = new Date();
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetAccessList")
                            .items
                            .select("FromDate", "UptoDate", "Username/EMail")
                            .expand("Username")
                            .top(5000)()];
                case 2:
                    items = _a.sent();
                    access = items.some(function (item) {
                        var _a;
                        var from = new Date(item.FromDate);
                        var upto = new Date(item.UptoDate);
                        return (((_a = item.Username) === null || _a === void 0 ? void 0 : _a.EMail) === user_1.Email &&
                            today_1 >= from &&
                            today_1 <= upto);
                    });
                    setHasAccess(access);
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.log(error_1);
                    setHasAccess(false);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        void checkUserAccess();
    }, []);
    // Loading
    if (hasAccess === null) {
        return React.createElement("h3", null, "Loading...");
    }
    // No Access
    if (!hasAccess) {
        return (React.createElement("div", { style: { padding: "40px" } },
            React.createElement("h2", { style: { color: "red" } }, "Access Denied"),
            React.createElement("p", null, "You do not have access to this portal.")));
    }
    if (page === "manage") {
        return React.createElement(ManageAccess_1.default, tslib_1.__assign({}, props));
    }
    if (page === "upload") {
        return React.createElement(UploadAccrual_1.default, null);
    }
    return (React.createElement("div", { className: "container-fluid" },
        React.createElement("div", { className: 'header' },
            React.createElement("h1", null, "Accrual Sheet")),
        React.createElement("div", { className: "PaddAll" },
            React.createElement("div", { className: "buttonContainer" },
                React.createElement("button", { className: "btn", onClick: function () { return setPage("manage"); } }, "Manage Access"),
                React.createElement("button", { className: "btn", onClick: function () { return setPage("upload"); } }, "Upload Accrual Sheet"),
                React.createElement("button", { className: "btn", onClick: function () { return setPage("report"); } }, "Adjustment Report")))));
}
//# sourceMappingURL=AccrualSheet.js.map