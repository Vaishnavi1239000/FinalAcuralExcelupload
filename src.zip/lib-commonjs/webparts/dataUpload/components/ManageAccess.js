"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = ManageAccess;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var DataUploadWebPart_1 = require("../DataUploadWebPart");
var react_1 = require("react");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/site-groups/web");
require("@pnp/sp/site-groups");
require("@pnp/sp/site-users/web");
var PeoplePicker_1 = require("@pnp/spfx-controls-react/lib/PeoplePicker");
var LeftArrow_png_1 = tslib_1.__importDefault(require("../assets/LeftArrow.png"));
var RightArrow_png_1 = tslib_1.__importDefault(require("../assets/RightArrow.png"));
function ManageAccess(props) {
    var _this = this;
    var _a = React.useState(0), pickerKey = _a[0], setPickerKey = _a[1];
    var _b = React.useState(""), division = _b[0], setDivision = _b[1];
    var _c = React.useState(""), fromDate = _c[0], setFromDate = _c[1];
    var _d = React.useState(""), uptoDate = _d[0], setUptoDate = _d[1];
    var _e = React.useState(""), dateError = _e[0], setDateError = _e[1];
    var _f = React.useState(null), selectedUser = _f[0], setSelectedUser = _f[1];
    var _g = React.useState(""), employeeName = _g[0], setEmployeeName = _g[1];
    var _h = React.useState([]), accessInfo = _h[0], setAccessInfo = _h[1];
    var _j = (0, react_1.useState)([]), filteredData = _j[0], setFilteredData = _j[1];
    // Pagination
    var itemsPerPage = 5;
    var _k = (0, react_1.useState)(1), currentPage = _k[0], setCurrentPage = _k[1];
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    // People Picker Context
    var peoplePickerContext = {
        absoluteUrl: props.context.pageContext.web.absoluteUrl,
        msGraphClientFactory: props.context.msGraphClientFactory,
        spHttpClient: props.context.spHttpClient
    };
    // Load data on page load
    // Fetch List Data
    //   const getAccessInfo = async () => {
    //   const items = await sp.web.lists
    //     .getByTitle("AccrualSheetAccessList")
    //     .items();
    // };
    // React.useEffect(() => {
    //   void getAccessInfo();
    // }, []);
    var getAccessInfo = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var items, data;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                        .getByTitle("AccrualSheetAccessList")
                        .items
                        .select("Title", "Division", "FromDate", "UptoDate", "Author/Title", "Editor/Title", "Created", "Modified")
                        .expand("Author", "Editor")
                        .orderBy("Created", false) // ✅ ADD THIS LINE
                        .top(5000)()];
                case 1:
                    items = _a.sent();
                    data = items.map(function (item) {
                        var _a, _b;
                        return ({
                            Division: item.Division,
                            EmployeeName: item.Title,
                            FromDate: new Date(item.FromDate).toLocaleDateString(),
                            UptoDate: new Date(item.UptoDate).toLocaleDateString(),
                            CreatedBy: (_a = item.Author) === null || _a === void 0 ? void 0 : _a.Title,
                            CreatedOn: new Date(item.Created).toLocaleDateString(),
                            UpdatedBy: (_b = item.Editor) === null || _b === void 0 ? void 0 : _b.Title,
                            UpdatedOn: new Date(item.Modified).toLocaleDateString()
                        });
                    });
                    setAccessInfo(data);
                    setFilteredData(data);
                    return [2 /*return*/];
            }
        });
    }); };
    var getAccessInfo1 = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var items, data;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0: return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                        .getByTitle("AccrualSheetAccessList")
                        .items
                        .select("Title", "Division", "FromDate", "UptoDate", "Author/Title", "Editor/Title", "Created", "Modified")
                        .expand("Author", "Editor")
                        .top(5000)()];
                case 1:
                    items = _a.sent();
                    data = items.map(function (item) {
                        var _a, _b;
                        return ({
                            Division: item.Division,
                            EmployeeName: item.Title,
                            FromDate: new Date(item.FromDate).toLocaleDateString(),
                            UptoDate: new Date(item.UptoDate).toLocaleDateString(),
                            CreatedBy: (_a = item.Author) === null || _a === void 0 ? void 0 : _a.Title,
                            CreatedOn: new Date(item.Created).toLocaleDateString(),
                            UpdatedBy: (_b = item.Editor) === null || _b === void 0 ? void 0 : _b.Title,
                            UpdatedOn: new Date(item.Modified).toLocaleDateString()
                        });
                    });
                    setAccessInfo(data);
                    return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        setDivision("Railway Business");
        //getAccessInfo();
        void getAccessInfo();
    }, []);
    var handleSave = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var user, users, _i, users_1, u, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!division || !fromDate || !uptoDate) {
                        alert("Division, From Date and Upto Date are required");
                        return [2 /*return*/];
                    }
                    if (uptoDate <= fromDate) {
                        alert("Upto Date must be greater than From Date");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 10, , 11]);
                    if (!selectedUser) return [3 /*break*/, 4];
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.ensureUser(selectedUser.loginName)];
                case 2:
                    user = _a.sent();
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists.getByTitle("AccrualSheetAccessList").items.add({
                            Title: employeeName,
                            Division: division,
                            FromDate: fromDate,
                            UptoDate: uptoDate,
                            UsernameId: user.Id,
                            Status: "Active"
                        })];
                case 3:
                    _a.sent();
                    return [3 /*break*/, 9];
                case 4: return [4 /*yield*/, DataUploadWebPart_1.sp.web.siteGroups
                        .getByName("AccrualUploadAccess")
                        .users()];
                case 5:
                    users = _a.sent();
                    _i = 0, users_1 = users;
                    _a.label = 6;
                case 6:
                    if (!(_i < users_1.length)) return [3 /*break*/, 9];
                    u = users_1[_i];
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists.getByTitle("AccrualSheetAccessList").items.add({
                            Title: u.Title,
                            Division: division,
                            FromDate: fromDate,
                            UptoDate: uptoDate,
                            UsernameId: u.Id,
                            Status: "Active"
                        })];
                case 7:
                    _a.sent();
                    _a.label = 8;
                case 8:
                    _i++;
                    return [3 /*break*/, 6];
                case 9:
                    alert("Access provided successfully");
                    setFromDate("");
                    setUptoDate("");
                    setSelectedUser(null);
                    setEmployeeName("");
                    // 👇 THIS LINE WILL CLEAR PEOPLE PICKER UI
                    setPickerKey(function (prev) { return prev + 1; });
                    void getAccessInfo();
                    return [3 /*break*/, 11];
                case 10:
                    error_1 = _a.sent();
                    console.log(error_1);
                    alert("Error saving data");
                    return [3 /*break*/, 11];
                case 11: return [2 /*return*/];
            }
        });
    }); };
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        //window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
    };
    // Save Button
    var handleSave1 = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var user, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    debugger;
                    if (!division || !selectedUser || !fromDate || !uptoDate) {
                        alert("All fields are required");
                        return [2 /*return*/];
                    }
                    if (uptoDate <= fromDate) {
                        alert("Upto Date must be greater than From Date");
                        setDateError("Upto Date must be greater than From Date");
                        return [2 /*return*/];
                    }
                    setDateError("");
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.ensureUser(selectedUser.loginName)];
                case 2:
                    user = _a.sent();
                    //UsernameId: user.Id
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists.getByTitle("AccrualSheetAccessList").items.add({
                            Title: employeeName,
                            Division: division,
                            FromDate: fromDate,
                            UptoDate: uptoDate,
                            UsernameId: user.Id
                        })];
                case 3:
                    //UsernameId: user.Id
                    _a.sent();
                    alert("Saved Successfully");
                    setFromDate("");
                    setUptoDate("");
                    setSelectedUser(null);
                    setEmployeeName("");
                    void getAccessInfo();
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _a.sent();
                    console.log(error_2);
                    alert("Error saving data");
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var th = {
        border: "1px solid #ccc",
        padding: "8px",
        textAlign: "center"
    };
    var td = {
        border: "1px solid #ccc",
        padding: "8px",
        textAlign: "center"
    };
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    var sortedData = tslib_1.__spreadArray([], filteredData, true).sort(function (a, b) { return b.ID - a.ID; });
    var paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (React.createElement("div", null,
        React.createElement("div", { className: 'header' },
            React.createElement("h1", null, "Manage Access")),
        React.createElement("div", { className: "PaddAll" },
            React.createElement("div", { className: 'row mb-20' },
                React.createElement("div", { className: 'col-md-3' },
                    React.createElement("label", { className: 'font' }, "Division"),
                    React.createElement("input", { value: division, className: 'form-control readonly' })),
                React.createElement("div", { className: "col-md-3" },
                    React.createElement("label", { className: 'font' }, "User Name"),
                    React.createElement(PeoplePicker_1.PeoplePicker, { key: pickerKey, context: peoplePickerContext, personSelectionLimit: 1, showtooltip: true, ensureUser: true, principalTypes: [PeoplePicker_1.PrincipalType.User], resolveDelay: 1000, onChange: function (items) {
                            if (items.length > 0) {
                                setSelectedUser(items[0]);
                                setEmployeeName(items[0].text || "");
                            }
                        } })),
                React.createElement("div", { className: "col-md-3" },
                    React.createElement("label", { className: 'font' }, "From Date"),
                    React.createElement("input", { type: "date", className: "form-control", value: fromDate, onChange: function (e) { return setFromDate(e.target.value); } })),
                React.createElement("div", { className: "col-md-3" },
                    React.createElement("label", { className: 'font' }, "Upto Date"),
                    React.createElement("input", { type: "date", className: "form-control", value: uptoDate, min: fromDate, onChange: function (e) { return setUptoDate(e.target.value); } }))),
            React.createElement("div", { className: "row mb-20" },
                React.createElement("div", { className: "col-md-12", style: { margin: "10px", textAlign: "end" } },
                    React.createElement("button", { className: "submit-btn", onClick: handleSave }, " Save "))),
            React.createElement("hr", { style: { border: "1px solid red" } }),
            React.createElement("div", { className: "heading1" },
                React.createElement("label", null, "Access Info")),
            React.createElement("div", { className: 'main-formcontainer' },
                React.createElement("div", { className: "overflow-x-auto" },
                    React.createElement("div", { className: "table-vert-scroll" },
                        React.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                            React.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                                React.createElement("tr", null,
                                    React.createElement("th", { className: "px-4 py-2" }, "S.No"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Division"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Employee Name"),
                                    React.createElement("th", { className: "px-4 py-2" }, "From Date"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Upto Date"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Created By"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Created On"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Updated By"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Updated On"))),
                            React.createElement("tbody", null, paginatedData.map(function (item, index) { return (React.createElement("tr", { key: index, className: "border-t" },
                                React.createElement("td", { className: "px-4 py-2" }, index + 1),
                                React.createElement("td", { className: "px-4 py-2" }, item.Division),
                                React.createElement("td", { className: "px-4 py-2" }, item.EmployeeName),
                                React.createElement("td", { className: "px-4 py-2" }, item.FromDate),
                                React.createElement("td", { className: "px-4 py-2" }, item.UptoDate),
                                React.createElement("td", { className: "px-4 py-2" }, item.CreatedBy),
                                React.createElement("td", { className: "px-4 py-2" }, item.CreatedOn),
                                React.createElement("td", { className: "px-4 py-2" }, item.UpdatedBy),
                                React.createElement("td", { className: "px-4 py-2" }, item.UpdatedOn))); })))),
                    React.createElement("div", { className: "flex justify-center mt-6 overflow-x-auto" },
                        React.createElement("div", { className: "flex space-x-2 flex-nowrap px-4 py-2 bg-#2149d5 rounded shadow", style: { textAlign: "end" } },
                            React.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1, style: {
                                    backgroundColor: "#fff",
                                    border: "1px solid #000 !important",
                                    marginRight: "5px",
                                    opacity: currentPage === 1 ? 0.5 : 1,
                                }, className: "px-3 py-1 border rounded" },
                                React.createElement("img", { src: LeftArrow_png_1.default, alt: "", width: 15 })),
                            Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                                .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                                .map(function (page) { return (React.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, style: {
                                    backgroundColor: currentPage === page ? "#3c3e45" : "#fff",
                                    color: currentPage === page ? "#fff" : "#000",
                                    fontWeight: currentPage === page ? "bold" : "normal",
                                    margin: currentPage === page ? "5px" : "5px",
                                }, className: "px-3 py-1 border rounded" }, page)); }),
                            React.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages, style: {
                                    backgroundColor: "#fff",
                                    border: "1px solid #000 !important",
                                    marginLeft: "5px",
                                    opacity: currentPage === totalPages ? 0.5 : 1,
                                }, className: "px-3 py-1 border rounded" },
                                React.createElement("img", { src: RightArrow_png_1.default, alt: "", width: 15 })))))),
            React.createElement("div", { style: { textAlign: "center", marginTop: "10px" } },
                React.createElement("button", { onClick: handleExit, className: "Reject-btn" }, " Exit ")))));
}
//# sourceMappingURL=ManageAccess.js.map