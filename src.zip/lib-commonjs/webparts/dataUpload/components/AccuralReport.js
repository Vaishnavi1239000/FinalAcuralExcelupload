"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = AccuralReport;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var react_1 = require("react");
var DataUploadWebPart_1 = require("../DataUploadWebPart");
var XLSX = tslib_1.__importStar(require("xlsx"));
var file_saver_1 = require("file-saver");
require("../components/Site.scss");
var react_router_dom_1 = require("react-router-dom");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var LeftArrow_png_1 = tslib_1.__importDefault(require("../assets/LeftArrow.png"));
var RightArrow_png_1 = tslib_1.__importDefault(require("../assets/RightArrow.png"));
function AccuralReport() {
    var _this = this;
    var _a = React.useState(false), isPerformer = _a[0], setIsPerformer = _a[1];
    var _b = React.useState(null), file = _b[0], setFile = _b[1];
    var _c = React.useState([]), data = _c[0], setData = _c[1];
    var _d = React.useState(false), isSearched = _d[0], setIsSearched = _d[1];
    var _e = React.useState(""), userName = _e[0], setUserName = _e[1];
    var _f = React.useState(""), department = _f[0], setDepartment = _f[1];
    var _g = React.useState(""), vendorName = _g[0], setVendorName = _g[1];
    var _h = React.useState(""), poNumber = _h[0], setPoNumber = _h[1];
    var _j = React.useState(""), fromDate = _j[0], setFromDate = _j[1];
    var _k = React.useState(""), toDate = _k[0], setToDate = _k[1];
    var _l = React.useState([]), userOptions = _l[0], setUserOptions = _l[1];
    var _m = React.useState([]), deptOptions = _m[0], setDeptOptions = _m[1];
    var _o = React.useState([]), vendorOptions = _o[0], setVendorOptions = _o[1];
    var _p = React.useState([]), poOptions = _p[0], setPoOptions = _p[1];
    var _q = (0, react_1.useState)([]), filteredData = _q[0], setFilteredData = _q[1];
    // Pagination
    var itemsPerPage = 10;
    var _r = (0, react_1.useState)(1), currentPage = _r[0], setCurrentPage = _r[1];
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    var history = (0, react_router_dom_1.useHistory)();
    // SEARCH DATA
    var Reset = function () {
        setUserName("");
        setDepartment("");
        setVendorName("");
        setPoNumber("");
        setFromDate("");
        setToDate("");
        setData([]);
        setIsSearched(false);
    };
    var loadDropdownData = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var items, unique, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.select("Username", "Department", "VendorName", "PONumber")
                            .top(5000)()];
                case 1:
                    items = _a.sent();
                    unique = function (arr, key) {
                        var result = [];
                        arr.forEach(function (item) {
                            var value = item[key];
                            if (value && result.indexOf(value) === -1) {
                                result.push(value);
                            }
                        });
                        return result;
                    };
                    setUserOptions(unique(items, "Username"));
                    setDeptOptions(unique(items, "Department"));
                    setVendorOptions(unique(items, "VendorName"));
                    setPoOptions(unique(items, "PONumber"));
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.log("Dropdown load error:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var checkUserAccess = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var user, groups, performer, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    user = _a.sent();
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.siteUsers.getById(user.Id).groups()];
                case 2:
                    groups = _a.sent();
                    performer = groups.some(function (g) { return g.Title === "AccrualPerformer"; });
                    setIsPerformer(performer);
                    return [3 /*break*/, 4];
                case 3:
                    error_2 = _a.sent();
                    console.log("Access check error", error_2);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
        // https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx
    };
    var searchData = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var filter, to, query, items;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    filter = [];
                    // Hide soft deleted records
                    filter.push("DeleteFlag ne 1");
                    if (userName)
                        filter.push("substringof('".concat(userName, "', Username)"));
                    if (department)
                        filter.push("substringof('".concat(department, "', Department)"));
                    if (vendorName)
                        filter.push("substringof('".concat(vendorName, "', VendorName)"));
                    if (poNumber)
                        filter.push("substringof('".concat(poNumber, "', PONumber)"));
                    // Date filter
                    // From Date
                    if (fromDate) {
                        filter.push("Created ge datetime'".concat(new Date(fromDate).toISOString(), "'"));
                    }
                    // To Date (FIXED)
                    if (toDate) {
                        to = new Date(toDate);
                        to.setDate(to.getDate() + 1);
                        filter.push("Created lt datetime'".concat(to.toISOString(), "'"));
                    }
                    query = filter.join(" and ");
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.filter(query)
                            .top(5000)()];
                case 1:
                    items = _a.sent();
                    setIsSearched(true);
                    setData(items);
                    setFilteredData(items);
                    return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        void checkUserAccess();
        void loadDropdownData(); // ✅ ADD THIS
    }, []);
    var exportExcel = function () {
        var exportData = data.map(function (item) { return ({
            UserName: item.Username,
            Department: item.Department,
            VendorName: item.VendorName,
            VendorCode: item.VendorCode,
            PONumber: item.PONumber,
            GLCode: item.GLCode,
            GLDescription: item.GLDescription,
            EmployeeCostCenter: item.EmployeeCostCenter,
            EmployeeCostCenterName: item.EmployeeCostCenterName,
            Amount: item.Amount,
            ExpenseMonth: item.ExpenseMonth,
            Remarks: item.Remarks,
        }); });
        var worksheet = XLSX.utils.json_to_sheet(exportData);
        var workbook = {
            Sheets: { "Accrual Report": worksheet },
            SheetNames: ["Accrual Report"],
        };
        var excelBuffer = XLSX.write(workbook, {
            bookType: "xlsx",
            type: "array",
        });
        var blob = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        (0, file_saver_1.saveAs)(blob, "Accrual_Report.xlsx");
    };
    // DELETE ROW
    var deleteItem = function (id) { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var confirmDelete, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    confirmDelete = window.confirm("Are you sure you want to delete the data?");
                    // ❌ If user clicks Cancel → stop
                    if (!confirmDelete) {
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("AccrualSheetList")
                            .items.getById(id)
                            .update({
                            DeleteFlag: true,
                        })];
                case 2:
                    _a.sent();
                    // ✅ Success message
                    alert("Data deleted successfully");
                    return [4 /*yield*/, searchData()];
                case 3:
                    _a.sent();
                    return [3 /*break*/, 5];
                case 4:
                    error_3 = _a.sent();
                    console.log("Delete error:", error_3);
                    alert("Error deleting data");
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var formatMonth = function (value) {
        if (!value)
            return "";
        // If it's a valid date → convert to month name
        var date = new Date(value);
        if (!isNaN(date.getTime())) {
            return date.toLocaleString("en-US", { month: "long" });
        }
        // If already string → capitalize properly
        var str = String(value).trim().toLowerCase();
        return str.charAt(0).toUpperCase() + str.slice(1);
    };
    // EXPORT CSV
    // const exportExcel = ()=>{
    // const csv = data.map(r=>Object.values(r).join(",")).join("\n")
    // const blob = new Blob([csv])
    // const url = URL.createObjectURL(blob)
    // const a = document.createElement("a")
    // a.href = url
    // a.download = "AccrualReport.csv"
    // a.click()
    // }
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    var sortedData = tslib_1.__spreadArray([], filteredData, true).sort(function (a, b) { return b.ID - a.ID; });
    var paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (React.createElement("div", null,
        React.createElement("div", { className: "header" },
            React.createElement("h1", null, "Accrual Report")),
        React.createElement("div", { className: "PaddAll" },
            React.createElement("div", { style: { display: "flex", gap: "10px", marginBottom: "20px" } },
                React.createElement("select", { value: userName, className: "form-control", onChange: function (e) { return setUserName(e.target.value); } },
                    React.createElement("option", { value: "" }, "All Users"),
                    userOptions.map(function (u, i) { return (React.createElement("option", { key: i, value: u }, u)); })),
                React.createElement("select", { value: department, className: "form-control", onChange: function (e) { return setDepartment(e.target.value); } },
                    React.createElement("option", { value: "" }, "All Departments"),
                    deptOptions.map(function (d, i) { return (React.createElement("option", { key: i, value: d }, d)); })),
                React.createElement("select", { value: vendorName, className: "form-control", onChange: function (e) { return setVendorName(e.target.value); } },
                    React.createElement("option", { value: "" }, "All Vendors"),
                    vendorOptions.map(function (v, i) { return (React.createElement("option", { key: i, value: v }, v)); })),
                React.createElement("select", { value: poNumber, className: "form-control", onChange: function (e) { return setPoNumber(e.target.value); } },
                    React.createElement("option", { value: "" }, "All PO"),
                    poOptions.map(function (p, i) { return (React.createElement("option", { key: i, value: p }, p)); })),
                React.createElement("input", { type: "date", className: "form-control", value: fromDate, onChange: function (e) { return setFromDate(e.target.value); } }),
                React.createElement("input", { type: "date", className: "form-control", value: toDate, onChange: function (e) { return setToDate(e.target.value); } })),
            React.createElement("div", { className: "", style: {
                    display: "block",
                    marginBottom: "20px",
                    textAlign: "center",
                } },
                React.createElement("button", { onClick: searchData, className: "submit-btn" }, "Search"),
                React.createElement("button", { onClick: exportExcel, className: "sendback-btn" }, "Export"),
                React.createElement("button", { onClick: Reset, className: "reset-btn" }, "Reset")),
            isSearched && (React.createElement("div", { className: "overflow-x-auto" },
                React.createElement("div", { className: "table-vert-scroll" },
                    React.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                        React.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                            React.createElement("tr", null,
                                React.createElement("th", { className: "px-4 py-2" }, "UserName"),
                                React.createElement("th", { className: "px-4 py-2" }, "Department"),
                                React.createElement("th", { className: "px-4 py-2" }, "Vendor Name"),
                                React.createElement("th", { className: "px-4 py-2" }, "Vendor Code"),
                                React.createElement("th", { className: "px-4 py-2" }, "PO Number"),
                                React.createElement("th", { className: "px-4 py-2" }, "GL Code"),
                                React.createElement("th", { className: "px-4 py-2" }, "Employee Cost Center"),
                                React.createElement("th", { className: "px-4 py-2" }, "Employee Cost Center Name"),
                                React.createElement("th", { className: "px-4 py-2" }, "Amount"),
                                React.createElement("th", { className: "px-4 py-2" }, "Expense Month"),
                                React.createElement("th", { className: "px-4 py-2" }, "Remarks"))),
                        React.createElement("tbody", null, paginatedData.map(function (item, index) { return (React.createElement("tr", { key: index, className: "border-t" },
                            React.createElement("td", { className: "px-4 py-2" }, item.Username),
                            React.createElement("td", { className: "px-4 py-2" }, item.Department),
                            React.createElement("td", { className: "px-4 py-2" }, item.VendorName),
                            React.createElement("td", { className: "px-4 py-2" }, item.VendorCode),
                            React.createElement("td", { className: "px-4 py-2" }, item.PONumber),
                            React.createElement("td", { className: "px-4 py-2" }, item.GLCode),
                            React.createElement("td", { className: "px-4 py-2" }, item.GLDescription),
                            React.createElement("td", { className: "px-4 py-2" }, item.EmployeeCostCenter),
                            React.createElement("td", { className: "px-4 py-2" }, item.Amount),
                            React.createElement("td", { className: "px-4 py-2" }, formatMonth(item.ExpenseMonth)),
                            React.createElement("td", { className: "px-4 py-2" }, item.Remarks))); })))),
                React.createElement("div", { className: "flex justify-center mt-6 overflow-x-auto" },
                    React.createElement("div", { className: "flex space-x-2 flex-nowrap px-4 py-2 bg-#2149d5 rounded shadow", style: { textAlign: "end" } },
                        React.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1, style: {
                                backgroundColor: "#fff",
                                border: "1px solid #000 !important",
                                marginRight: "5px",
                                opacity: currentPage === 1 ? 0.5 : 1,
                            }, className: "px-3 py-1 border rounded" },
                            React.createElement("img", { src: LeftArrow_png_1.default, alt: "", width: 15 })),
                        Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                            .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                            .map(function (page) { return (React.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, style: {
                                backgroundColor: currentPage === page ? "#3c3e45" : "#fff",
                                color: currentPage === page ? "#fff" : "#000",
                                fontWeight: currentPage === page ? "bold" : "normal",
                                margin: currentPage === page ? "5px" : "5px",
                            }, className: "px-3 py-1 border rounded" }, page)); }),
                        React.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages, style: {
                                backgroundColor: "#fff",
                                border: "1px solid #000 !important",
                                marginLeft: "5px",
                                opacity: currentPage === totalPages ? 0.5 : 1,
                            }, className: "px-3 py-1 border rounded" },
                            React.createElement("img", { src: RightArrow_png_1.default, alt: "", width: 15 })))))),
            isPerformer && (React.createElement("div", { style: { textAlign: "center", marginTop: "10px" } },
                React.createElement("button", { onClick: handleExit, className: "Reject-btn" },
                    " ",
                    "Exit",
                    " "))))));
}
//# sourceMappingURL=AccuralReport.js.map