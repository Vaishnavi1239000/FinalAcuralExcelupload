"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = UploadAccrual;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
require("./UploadAccrual.scss");
var sp_loader_1 = require("@microsoft/sp-loader");
var DataUploadWebPart_1 = require("../DataUploadWebPart");
require("@pnp/sp/webs");
require("@pnp/sp/site-users/web");
require("@pnp/sp/lists");
require("@pnp/sp/items");
require("@pnp/sp/files");
require("@pnp/sp/folders");
var XLSX = tslib_1.__importStar(require("xlsx"));
sp_loader_1.SPComponentLoader.loadCss("https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css");
function UploadAccrual() {
    var _this = this;
    var _a, _b;
    var _c = React.useState(null), file = _c[0], setFile = _c[1];
    var _d = React.useState(null), selectedUser = _d[0], setSelectedUser = _d[1];
    var _e = React.useState([]), excelData = _e[0], setExcelData = _e[1];
    var _f = React.useState([]), data = _f[0], setData = _f[1];
    var _g = React.useState([]), filteredData = _g[0], setFilteredData = _g[1];
    var _h = React.useState(false), isSearched = _h[0], setIsSearched = _h[1];
    var _j = React.useState({}), employee = _j[0], setEmployee = _j[1];
    var normalize = function (str) { return str.trim().toLowerCase(); };
    var requiredColumns = [
        "UserName ",
        "Department ",
        "Vendor Name",
        "Vendor Code ",
        "PO Number",
        "GL Code ",
        "GL Description ",
        "Employee Cost Center ",
        "Employee Cost Center Name ",
        "Amount ",
        "Expense Month ",
        "Remarks (if any)",
    ];
    var validateTemplate = function (data) {
        if (data.length === 0) {
            alert("Uploaded file is empty");
            return false;
        }
        var fileHeaders = Object.keys(data[0]).map(normalize);
        var required = requiredColumns.map(normalize);
        // Check missing columns
        var missing = required.filter(function (col) { return !fileHeaders.includes(col); });
        // Check extra columns
        var extra = fileHeaders.filter(function (col) { return !required.includes(col); });
        if (missing.length > 0) {
            alert("Missing columns: " + missing.join(", "));
            return false;
        }
        if (extra.length > 0) {
            alert("Invalid extra columns: " + extra.join(", "));
            return false;
        }
        return true;
    };
    var handleFileChange = function (e) {
        if (e.target.files && e.target.files.length > 0) {
            var selectedFile = e.target.files[0];
            setFile(selectedFile);
            console.log("Selected file:", selectedFile.name);
        }
        // ✅ Reset input so same file can be selected again
        e.target.value = "";
    };
    var getLoggedInUser = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var currentUser, email, user, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 3, , 4]);
                    // get logged in user
                    debugger;
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.currentUser()];
                case 1:
                    currentUser = _a.sent();
                    email = currentUser.Email;
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("EmployeeMaster")
                            .items.select("EmployeeCode", "EmployeeName", "Division", "Location", "EmployeeEmail", "ReportingManager/Title", "HOD/Title", "ContactNo", "EmployeeStatus")
                            .expand("ReportingManager", "HOD")
                            .filter("EmployeeEmail eq '".concat(email, "'"))
                            .top(1)()];
                case 2:
                    user = _a.sent();
                    if (user.length > 0) {
                        setEmployee(user[0]);
                    }
                    console.log(user);
                    return [3 /*break*/, 4];
                case 3:
                    error_1 = _a.sent();
                    console.log("Error fetching user:", error_1);
                    alert(error_1);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    React.useEffect(function () {
        void getLoggedInUser();
    }, []);
    var downloadTemplate = function () {
        // Create empty row with only headers
        var worksheet = XLSX.utils.json_to_sheet([]);
        // Add headers manually
        XLSX.utils.sheet_add_aoa(worksheet, [requiredColumns]);
        var workbook = {
            Sheets: { Template: worksheet },
            SheetNames: ["Template"],
        };
        var excelBuffer = XLSX.write(workbook, {
            bookType: "xlsx",
            type: "array",
        });
        var blob = new Blob([excelBuffer], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        var fileName = "Accrual_Template.xlsx";
        var link = document.createElement("a");
        link.href = URL.createObjectURL(blob);
        link.download = fileName;
        link.click();
    };
    //   const submitData = async () => {
    //     if (excelData.length === 0) {
    //       alert("No data to submit");
    //       return;
    //     }
    //     // ✅ Month mapping (for validation logic)
    //     const getMonthNumber = (monthName: string) => {
    //       const months: any = {
    //         january: 0,
    //         february: 1,
    //         march: 2,
    //         april: 3,
    //         may: 4,
    //         june: 5,
    //         july: 6,
    //         august: 7,
    //         september: 8,
    //         october: 9,
    //         november: 10,
    //         december: 11,
    //       };
    //       return months[monthName.trim().toLowerCase()];
    //     };
    //     // ✅ Capitalize Month (FINAL FIX)
    //     const capitalizeMonth = (month: string) => {
    //       const m = month.trim().toLowerCase();
    //       return m.charAt(0).toUpperCase() + m.slice(1);
    //     };
    //     const today = new Date();
    //     const currentMonth = today.getMonth();
    //     const currentDate = today.getDate();
    //     let skippedUsers: string[] = [];
    //     try {
    //       for (let i = 0; i < excelData.length; i++) {
    //         const row = excelData[i];
    //         const username = String(row["UserName "] || "Unknown");
    //         // ✅ Required validation
    //         for (const col of requiredColumns) {
    //           if (!row[col] || row[col].toString().trim() === "") {
    //             alert(`Row ${i + 2}: ${col} is required`);
    //             return;
    //           }
    //         }
    //         // ✅ Amount validation
    //         if (isNaN(Number(row["Amount "]))) {
    //           alert(`Row ${i + 2}: Amount must be numeric`);
    //           return;
    //         }
    //         // ✅ Get & format month
    //         const expenseMonthRaw = String(row["Expense Month "] || "");
    //         const expenseMonthStr = capitalizeMonth(expenseMonthRaw); // 👈 SAVED VALUE (April)
    //         const expMonth = getMonthNumber(expenseMonthStr.toLowerCase()); // 👈 LOGIC VALUE
    //         if (expMonth === undefined) {
    //           skippedUsers.push(username);
    //           continue;
    //         }
    //         let isValid = false;
    //         // ✅ Current month allowed
    //         if (expMonth === currentMonth) {
    //           isValid = true;
    //         }
    //         // ✅ Previous month till 5th
    //         const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    //         if (expMonth === prevMonth && currentDate <= 5) {
    //           isValid = true;
    //         }
    //         // ✅ Future months allowed
    //         if (expMonth > currentMonth) {
    //           isValid = true;
    //         }
    //         // ❌ Skip invalid month
    //         if (!isValid) {
    //           skippedUsers.push(username);
    //           continue;
    //         }
    //         // ✅ INSERT INTO SHAREPOINT
    //         await sp.web.lists.getByTitle("AccrualSheetList").items.add({
    //           Title: username,
    //           Username: username,
    //           Department: String(row["Department "] || ""),
    //           VendorName: String(row["Vendor Name"] || ""),
    //           VendorCode: String(row["Vendor Code "] || ""),
    //           PONumber: String(row["PO Number"] || ""),
    //           GLCode: String(row["GL Code "] || ""),
    //           GLDescription: String(row["GL Description "] || ""),
    //           EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
    //           EmployeeCostCenterName: String(
    //             row["Employee Cost Center Name "] || "",
    //           ),
    //           Amount: Number(row["Amount "] || 0),
    //           // ✅ FINAL OUTPUT → "April"
    //           ExpenseMonth: expenseMonthStr,
    //           Remarks: String(row["Remarks (if any)"] || ""),
    //           Status: "Pending",
    //         });
    //       }
    //       // ✅ Remove duplicates from skipped users
    //       const uniqueSkipped = skippedUsers.filter((v, i) => {
    //         return skippedUsers.indexOf(v) === i;
    //       });
    //       // ✅ Final message
    //       if (uniqueSkipped.length > 0) {
    //         alert(
    //           `Data for past months cannot be uploaded \nSkipped (invalid month): ${uniqueSkipped.join(", ")}`,
    //         );
    //       } else {
    //         alert("Accrual details submitted successfully");
    //       }
    //       // ✅ Reset
    //       setExcelData([]);
    //       setFile(null);
    //     } catch (error) {
    //       console.log("Error:", error);
    //       alert("Error saving data");
    //     }
    //   };
    // const submitData = async () => {
    //     if (excelData.length === 0) {
    //         alert("No data to submit");
    //         return;
    //     }
    //     // ✅ Helper: Convert month name to number
    //     const getMonthNumber = (monthName: string) => {
    //         const months: any = {
    //             january: 0,
    //             february: 1,
    //             march: 2,
    //             april: 3,
    //             may: 4,
    //             june: 5,
    //             july: 6,
    //             august: 7,
    //             september: 8,
    //             october: 9,
    //             november: 10,
    //             december: 11
    //         };
    //         return months[monthName.toLowerCase()];
    //     };
    //     const today = new Date();
    //     const currentMonth = today.getMonth();
    //     const currentYear = today.getFullYear();
    //     const currentDate = today.getDate();
    //     let skippedUsers: string[] = [];
    //     try {
    //         for (let i = 0; i < excelData.length; i++) {
    //             const row = excelData[i];
    //             const username = String(row["UserName "] || "Unknown");
    //             // ✅ Required validation
    //             for (const col of requiredColumns) {
    //                 if (!row[col] || row[col].toString().trim() === "") {
    //                     alert(`Row ${i + 2}: ${col} is required`);
    //                     return;
    //                 }
    //             }
    //             // ✅ Amount validation
    //             if (isNaN(Number(row["Amount "]))) {
    //                 alert(`Row ${i + 2}: Amount must be numeric`);
    //                 return;
    //             }
    //             // ✅ Month validation
    //             const expenseMonthStr = String(row["Expense Month "] || "").trim().toLowerCase();
    //             const expMonth = getMonthNumber(expenseMonthStr);
    //             if (expMonth === undefined) {
    //                 skippedUsers.push(username);
    //                 continue;
    //             }
    //             const expYear = currentYear;
    //             let isValid = false;
    //             // ✅ Current month allowed
    //             if (expMonth === currentMonth) {
    //                 isValid = true;
    //             }
    //             // ✅ Previous month allowed only till 5th
    //             const prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    //             const prevYear = currentMonth === 0 ? currentYear - 1 : currentYear;
    //             if (
    //                 expMonth === prevMonth &&
    //                 expYear === prevYear &&
    //                 currentDate <= 5
    //             ) {
    //                 isValid = true;
    //             }
    //             // ❌ Skip invalid rows
    //             if (!isValid) {
    //                 skippedUsers.push(username);
    //                 continue;
    //             }
    //             // ✅ Insert valid data
    //             await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items.add({
    //                     Title: username,
    //                     Username: username,
    //                     Department: String(row["Department "] || ""),
    //                     VendorName: String(row["Vendor Name"] || ""),
    //                     VendorCode: String(row["Vendor Code "] || ""),
    //                     PONumber: String(row["PO Number"] || ""),
    //                     GLCode: String(row["GL Code "] || ""),
    //                     GLDescription: String(row["GL Description "] || ""),
    //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
    //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
    //                     Amount: Number(row["Amount "] || 0),
    //                     ExpenseMonth: expenseMonthStr,
    //                     Remarks: String(row["Remarks (if any)"] || ""),
    //                     Status: "Pending"
    //                 });
    //         }
    //         // ✅ Remove duplicate usernames in message
    //         const uniqueSkippedUsers = skippedUsers.filter((item, index) => {
    //             return skippedUsers.indexOf(item) === index;
    //         });
    //         // ✅ Final message
    //         if (uniqueSkippedUsers.length > 0) {
    //             alert(`Upload complete ✅\nSkipped users (invalid month): ${uniqueSkippedUsers.join(", ")}`);
    //         } else {
    //             alert("Data saved successfully");
    //         }
    //         // ✅ Reset
    //         setExcelData([]);
    //         setFile(null);
    //     } catch (error) {
    //         console.log("Save error:", error);
    //         alert("Error saving data");
    //     }
    // };
    // const submitData = async () => {
    //     if (excelData.length === 0) {
    //         alert("No data to submit");
    //         return;
    //     }
    //     // Validate rows
    //     for (let i = 0; i < excelData.length; i++) {
    //         const row = excelData[i];
    //         // Check required fields
    //         for (const col of requiredColumns) {
    //             if (!row[col] || row[col].toString().trim() === "") {
    //                 alert(`Row ${i + 2}: ${col} is required`);
    //                 return;
    //             }
    //         }
    //         // Validate Amount numeric
    //         if (isNaN(Number(row["Amount "]))) {
    //             alert(`Row ${i + 2}: Amount must be numeric`);
    //             return;
    //         }
    //     }
    //     try {
    //         for (const row of excelData) {
    //             const username = String(row["UserName "] || "");
    //             const poNumber = String(row["PO Number"] || "");
    //             const expenseMonth = String(row["Expense Month "] || "");
    //             // Duplicate check
    //             const existingItems = await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items
    //                 .filter(`Username eq '${username}' and PONumber eq '${poNumber}' and ExpenseMonth eq '${expenseMonth}'`)
    //                 .top(1)();
    //             if (existingItems.length > 0) {
    //                 const item = existingItems[0];
    //                 // If record was soft deleted
    //                 if (item.DeleteFlag === true) {
    //                     // Delete old record permanently
    //                     await sp.web.lists
    //                         .getByTitle("AccrualSheetList")
    //                         .items
    //                         .getById(item.Id)
    //                         .delete();
    //                 } else {
    //                     console.log("Duplicate skipped:", username, poNumber);
    //                     continue;   // skip saving
    //                 }
    //             }
    //             if (existingItems.length > 0) {
    //                 console.log("Duplicate skipped:", username, poNumber);
    //                 continue;
    //             }
    //             await sp.web.lists
    //                 .getByTitle("AccrualSheetList")
    //                 .items.add({
    //                     Title: username,
    //                     Username: username,
    //                     Department: String(row["Department "] || ""),
    //                     VendorName: String(row["Vendor Name"] || ""),
    //                     VendorCode: String(row["Vendor Code "] || ""),
    //                     PONumber: poNumber,
    //                     GLCode: String(row["GL Code "] || ""),
    //                     GLDescription: String(row["GL Description "] || ""),
    //                     EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
    //                     EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
    //                     Amount: Number(row["Amount "] || 0),
    //                     ExpenseMonth: expenseMonth,
    //                     Remarks: String(row["Remarks (if any)"] || ""),
    //                     Status: "Pending"
    //                 });
    //         }
    //         alert("Data saved successfully");
    //         // ✅ Clear states
    //         setExcelData([]);
    //         setFile(null);
    //         // ✅ Reload your data (if you have a function like this)
    //       // await  getAllData(); // or whatever function you use to fetch list
    //     } catch (error) {
    //         console.log("Save error:", error);
    //         alert("Error saving data");
    //     }
    // };
    var submitData = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var getMonthNumber, capitalizeMonth, today, currentMonth, currentDate, skippedUsers, skippedRows, i, row, username, _i, requiredColumns_1, col, expenseMonthRaw, expenseMonthStr, expMonth, isValid, prevMonth, uniqueSkipped, error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (excelData.length === 0) {
                        alert("No data to submit");
                        return [2 /*return*/];
                    }
                    getMonthNumber = function (monthName) {
                        var months = {
                            january: 0,
                            february: 1,
                            march: 2,
                            april: 3,
                            may: 4,
                            june: 5,
                            july: 6,
                            august: 7,
                            september: 8,
                            october: 9,
                            november: 10,
                            december: 11,
                        };
                        return months[monthName.trim().toLowerCase()];
                    };
                    capitalizeMonth = function (month) {
                        var m = month.trim().toLowerCase();
                        return m.charAt(0).toUpperCase() + m.slice(1);
                    };
                    today = new Date();
                    currentMonth = today.getMonth();
                    currentDate = today.getDate();
                    skippedUsers = [];
                    skippedRows = [];
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 6, , 7]);
                    i = 0;
                    _a.label = 2;
                case 2:
                    if (!(i < excelData.length)) return [3 /*break*/, 5];
                    row = excelData[i];
                    username = String(row["UserName "] || "Unknown");
                    // ✅ Required validation
                    for (_i = 0, requiredColumns_1 = requiredColumns; _i < requiredColumns_1.length; _i++) {
                        col = requiredColumns_1[_i];
                        if (!row[col] || row[col].toString().trim() === "") {
                            alert("Row ".concat(i + 2, ": ").concat(col, " is required"));
                            return [2 /*return*/];
                        }
                    }
                    // ✅ Amount validation
                    if (isNaN(Number(row["Amount "]))) {
                        alert("Row ".concat(i + 2, ": Amount must be numeric"));
                        return [2 /*return*/];
                    }
                    expenseMonthRaw = String(row["Expense Month "] || "");
                    expenseMonthStr = capitalizeMonth(expenseMonthRaw);
                    expMonth = getMonthNumber(expenseMonthStr.toLowerCase());
                    if (expMonth === undefined) {
                        skippedUsers.push(username);
                        // ✅ PUSH TO GRID
                        skippedRows.push({
                            Id: 0,
                            Username: username,
                            Department: row["Department "] || "",
                            VendorName: row["Vendor Name"] || "",
                            VendorCode: row["Vendor Code "] || "",
                            PONumber: row["PO Number"] || "",
                            GLCode: row["GL Code "] || "",
                            GLDescription: row["GL Description "] || "",
                            EmployeeCostCenter: row["Employee Cost Center "] || "",
                            EmployeeCostCenterName: row["Employee Cost Center Name "] || "",
                            Amount: Number(row["Amount "] || 0),
                            ExpenseMonth: expenseMonthStr,
                            Remarks: row["Remarks (if any)"] || "",
                        });
                        return [3 /*break*/, 4];
                    }
                    isValid = false;
                    // ✅ Current month
                    if (expMonth === currentMonth) {
                        isValid = true;
                    }
                    prevMonth = currentMonth === 0 ? 11 : currentMonth - 1;
                    if (expMonth === prevMonth && currentDate <= 5) {
                        isValid = true;
                    }
                    // ✅ Future months
                    if (expMonth > currentMonth) {
                        isValid = true;
                    }
                    // ❌ Skip past months
                    if (!isValid) {
                        skippedUsers.push(username);
                        // ✅ PUSH TO GRID
                        skippedRows.push({
                            Id: 0,
                            Username: username,
                            Department: row["Department "] || "",
                            VendorName: row["Vendor Name"] || "",
                            VendorCode: row["Vendor Code "] || "",
                            PONumber: row["PO Number"] || "",
                            GLCode: row["GL Code "] || "",
                            GLDescription: row["GL Description "] || "",
                            EmployeeCostCenter: row["Employee Cost Center "] || "",
                            EmployeeCostCenterName: row["Employee Cost Center Name "] || "",
                            Amount: Number(row["Amount "] || 0),
                            ExpenseMonth: expenseMonthStr,
                            Remarks: row["Remarks (if any)"] || "",
                        });
                        return [3 /*break*/, 4];
                    }
                    // ✅ SAVE VALID DATA
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists.getByTitle("AccrualSheetList").items.add({
                            Title: username,
                            Username: username,
                            Department: String(row["Department "] || ""),
                            VendorName: String(row["Vendor Name"] || ""),
                            VendorCode: String(row["Vendor Code "] || ""),
                            PONumber: String(row["PO Number"] || ""),
                            GLCode: String(row["GL Code "] || ""),
                            GLDescription: String(row["GL Description "] || ""),
                            EmployeeCostCenter: String(row["Employee Cost Center "] || ""),
                            EmployeeCostCenterName: String(row["Employee Cost Center Name "] || ""),
                            Amount: Number(row["Amount "] || 0),
                            ExpenseMonth: expenseMonthStr,
                            Remarks: String(row["Remarks (if any)"] || ""),
                            Status: "Pending",
                        })];
                case 3:
                    // ✅ SAVE VALID DATA
                    _a.sent();
                    _a.label = 4;
                case 4:
                    i++;
                    return [3 /*break*/, 2];
                case 5:
                    uniqueSkipped = skippedUsers.filter(function (v, i) {
                        return skippedUsers.indexOf(v) === i;
                    });
                    // ✅ SHOW MESSAGE
                    if (uniqueSkipped.length > 0) {
                        alert("Past month data not allowed \u274C\nShown in grid for correction:\n".concat(uniqueSkipped.join(", ")));
                        // ✅ SHOW SKIPPED DATA IN GRID
                        setData(skippedRows);
                        setFilteredData(skippedRows);
                        setIsSearched(true);
                    }
                    else {
                        alert("Accrual details submitted successfully ✅");
                        // ✅ CLEAR GRID
                        setData([]);
                        setFilteredData([]);
                        setIsSearched(false);
                    }
                    setExcelData([]);
                    setFile(null);
                    return [3 /*break*/, 7];
                case 6:
                    error_2 = _a.sent();
                    console.log("Error:", error_2);
                    alert("Error saving data");
                    return [3 /*break*/, 7];
                case 7: return [2 /*return*/];
            }
        });
    }); };
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
    };
    var exitPage = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        return tslib_1.__generator(this, function (_a) {
            // setExcelData([]);
            // setFile(null);
            // await getLoggedInUser(); // reload data
            window.location.href = "".concat(window.location.origin, "/sites/SonaFinance/SitePages/Accuralsheet.aspx");
            return [2 /*return*/];
        });
    }); };
    var Resetpage = function () {
        setExcelData([]);
        setFile(null);
        // await getLoggedInUser(); // reload data
    };
    //   const exitPage = () => {
    //   setExcelData([]);
    //   setFile(null);
    //   await getLoggedInUser();
    //   //setPage("home"); // ✅ Redirect to home
    // };
    var downloadTemplate1 = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var files, error_3;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("Accrualtemplate")
                            .items.select("FileRef", "FileLeafRef", "Modified")
                            .orderBy("Modified", false) // false = descending (latest first)
                            .top(1)()];
                case 1:
                    files = _a.sent();
                    if (files.length > 0) {
                        window.open(files[0].FileRef, "_blank");
                    }
                    return [3 /*break*/, 3];
                case 2:
                    error_3 = _a.sent();
                    console.log("Download error:", error_3);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    var uploadFile = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var fileBuffer, workbook, sheetName, sheet, data_1, isValid, error_4;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!file) {
                        alert("Please select file");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 3, , 4]);
                    return [4 /*yield*/, file.arrayBuffer()];
                case 2:
                    fileBuffer = _a.sent();
                    workbook = XLSX.read(fileBuffer, { type: "array" });
                    sheetName = workbook.SheetNames[0];
                    sheet = workbook.Sheets[sheetName];
                    data_1 = XLSX.utils.sheet_to_json(sheet);
                    isValid = validateTemplate(data_1);
                    if (!isValid) {
                        setExcelData([]);
                        alert("Invalid template. Please use the correct format.");
                        return [2 /*return*/];
                    }
                    // ✅ Only set data if valid
                    setExcelData(data_1);
                    alert("File validated and uploaded successfully");
                    return [3 /*break*/, 4];
                case 3:
                    error_4 = _a.sent();
                    console.log("Upload error:", error_4);
                    return [3 /*break*/, 4];
                case 4: return [2 /*return*/];
            }
        });
    }); };
    var uploadFile1 = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var fileBuffer, fileName, workbook, sheetName, sheet, data_2, error_5;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!file) {
                        alert("Please select file");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, file.arrayBuffer()];
                case 2:
                    fileBuffer = _a.sent();
                    fileName = file.name;
                    // Upload to SharePoint
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web
                            .getFolderByServerRelativePath("/sites/SonaFinance/UploadAccuralTemplate")
                            .files.addUsingPath(fileName, fileBuffer, { Overwrite: true })];
                case 3:
                    // Upload to SharePoint
                    _a.sent();
                    alert("File uploaded successfully");
                    workbook = XLSX.read(fileBuffer, { type: "array" });
                    sheetName = workbook.SheetNames[0];
                    sheet = workbook.Sheets[sheetName];
                    data_2 = XLSX.utils.sheet_to_json(sheet);
                    setExcelData(data_2);
                    return [3 /*break*/, 5];
                case 4:
                    error_5 = _a.sent();
                    console.log("Upload error:", error_5);
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    return (React.createElement("div", null,
        React.createElement("div", { className: "header" },
            React.createElement("h1", null, "Upload Accrual Sheet")),
        React.createElement("div", { style: { padding: "10px" } },
            React.createElement("div", { className: "heading1" },
                React.createElement("label", null, "Requestor Information")),
            React.createElement("div", { className: "main-formcontainer" },
                React.createElement("div", { className: "row mb-20" },
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Employee Code", className: "font" }, "Employee Code"),
                        React.createElement("input", { value: employee.EmployeeCode || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Employee Name", className: "font" },
                            "Employee Name",
                            " "),
                        React.createElement("input", { value: employee.EmployeeName || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Employee Email", className: "font" },
                            "Employee Email",
                            " "),
                        React.createElement("input", { value: employee.EmployeeEmail || "", className: "form-control readonly" }))),
                React.createElement("div", { className: "row mb-20" },
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Contact No", className: "font" }, "Contact No"),
                        React.createElement("input", { value: employee.ContactNo || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Employee Status", className: "font" }, "Employee Status"),
                        React.createElement("input", { value: employee.EmployeeStatus || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Division", className: "font" }, "Division"),
                        React.createElement("input", { value: employee.Division || "", className: "form-control readonly" }))),
                React.createElement("div", { className: "row mb-20" },
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "Location", className: "font" }, "Location"),
                        React.createElement("input", { value: employee.Location || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "RM", className: "font" }, "RM"),
                        React.createElement("input", { value: ((_a = employee.ReportingManager) === null || _a === void 0 ? void 0 : _a.Title) || "", className: "form-control readonly" })),
                    React.createElement("div", { className: "col-md-4" },
                        React.createElement("label", { htmlFor: "HOD", className: "font" }, "HOD"),
                        React.createElement("input", { value: ((_b = employee.HOD) === null || _b === void 0 ? void 0 : _b.Title) || "", className: "form-control readonly" }))))),
        React.createElement("div", { style: { padding: "0px 10px" } },
            React.createElement("div", { className: "row" },
                React.createElement("div", { className: "col-md-4" },
                    React.createElement("div", null,
                        React.createElement("button", { className: "primaryBtn", onClick: downloadTemplate }, "Download Template"),
                        React.createElement("p", { style: { color: "red", fontSize: "12px" } }, "Download the above template to upload the data")))),
            React.createElement("div", { className: "row" },
                React.createElement("div", { className: "col-md-12", style: {
                        display: "flex",
                        gap: "15px",
                        margin: "0px 10px",
                        alignItems: "center",
                    } },
                    React.createElement("div", null,
                        React.createElement("label", null, "Select Excel File"),
                        React.createElement("input", { type: "file", accept: ".xlsx", onChange: handleFileChange }),
                        file && React.createElement("p", null,
                            "Selected: ",
                            file.name)),
                    React.createElement("div", null,
                        React.createElement("button", { className: "primaryBtn", onClick: uploadFile },
                            " ",
                            "Upload Accrual Sheet"))))),
        excelData.length > 0 && (React.createElement("table", { style: {
                width: "100%",
                borderCollapse: "collapse",
                marginTop: "30px",
            } },
            React.createElement("thead", null,
                React.createElement("tr", null, Object.keys(excelData[0]).map(function (key) { return (React.createElement("th", { key: key, style: {
                        border: "1px solid #ccc",
                        padding: "8px",
                        background: "#f3f3f3",
                    } }, key)); }))),
            React.createElement("tbody", null, excelData.map(function (row, index) { return (React.createElement("tr", { key: index }, Object.values(row).map(function (value, i) { return (React.createElement("td", { key: i, style: {
                    border: "1px solid #ccc",
                    padding: "8px",
                } }, value)); }))); })))),
        React.createElement("div", { style: {
                display: "flex",
                gap: "5px",
                padding: "8px",
                justifyContent: "center",
            } },
            React.createElement("div", null,
                React.createElement("button", { className: "submit-btn", onClick: submitData, disabled: excelData.length === 0, style: {
                        opacity: excelData.length === 0 ? 0.5 : 1,
                        cursor: excelData.length === 0 ? "not-allowed" : "pointer",
                    } }, "Submit")),
            React.createElement("div", null,
                React.createElement("button", { className: "reset-btn", onClick: Resetpage }, "Reset")),
            React.createElement("div", null,
                React.createElement("button", { onClick: handleExit, className: "Reject-btn" },
                    " ",
                    "Exit",
                    " ")))));
}
//# sourceMappingURL=UploadAccrual.js.map