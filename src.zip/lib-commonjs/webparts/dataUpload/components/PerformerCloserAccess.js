"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = PerformerClosureAccess;
var tslib_1 = require("tslib");
var React = tslib_1.__importStar(require("react"));
var DataUploadWebPart_1 = require("../DataUploadWebPart");
require("@pnp/sp/webs");
require("@pnp/sp/lists");
require("@pnp/sp/items");
var react_1 = require("react");
var LeftArrow_png_1 = tslib_1.__importDefault(require("../assets/LeftArrow.png"));
var RightArrow_png_1 = tslib_1.__importDefault(require("../assets/RightArrow.png"));
function PerformerClosureAccess() {
    var _this = this;
    var _a = React.useState(""), division = _a[0], setDivision = _a[1];
    var _b = React.useState(""), fromDate = _b[0], setFromDate = _b[1];
    var _c = React.useState(""), uptoDate = _c[0], setUptoDate = _c[1];
    var _d = React.useState([]), historyData = _d[0], setHistoryData = _d[1];
    var _e = (0, react_1.useState)([]), filteredData = _e[0], setFilteredData = _e[1];
    // Pagination
    var itemsPerPage = 5;
    var _f = (0, react_1.useState)(1), currentPage = _f[0], setCurrentPage = _f[1];
    var totalPages = Math.ceil(filteredData.length / itemsPerPage);
    // ✅ Financial Year dropdown
    var getFinancialYears = function () {
        var currentYear = new Date().getFullYear();
        var years = [];
        for (var i = 0; i < 5; i++) {
            var start = currentYear - i;
            var end = start + 1;
            years.push("".concat(start, "-").concat(end));
        }
        return years;
    };
    var handleExit = function () {
        //https://isriglobal.sharepoint.com/sites/SonaFinance/_layouts/workbench.aspx
        // window.location.href = `${window.location.origin}/sites/SonaFinance/SitePages/Accuralsheet.aspx`;
        window.location.href = "https://sonacomstargroup.sharepoint.com/sites/RLY_Finance_UAT/SitePages/Accuralsheet.aspx";
    };
    // ✅ Fetch data
    var getHistoryData = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var items, data, error_1;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    _a.trys.push([0, 2, , 3]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("PerformerClosureAccess")
                            .items
                            .select("FinancialYear", "Month", "DateofClosure", "Created", "Author/Title")
                            .expand("Author")
                            .orderBy("Created", false)
                            .top(5000)()];
                case 1:
                    items = _a.sent();
                    data = items.map(function (item) {
                        var _a;
                        return ({
                            FinancialYear: item.FinancialYear,
                            Month: item.Month,
                            DateofClosure: new Date(item.DateofClosure).toLocaleDateString(),
                            CreatedBy: (_a = item.Author) === null || _a === void 0 ? void 0 : _a.Title,
                            CreatedOn: new Date(item.Created).toLocaleDateString()
                        });
                    });
                    setHistoryData(data);
                    setFilteredData(data);
                    return [3 /*break*/, 3];
                case 2:
                    error_1 = _a.sent();
                    console.log("Fetch error:", error_1);
                    return [3 /*break*/, 3];
                case 3: return [2 /*return*/];
            }
        });
    }); };
    // ✅ Load on page load
    React.useEffect(function () {
        void getHistoryData();
    }, []);
    // ✅ Save function
    var handleSave = function () { return tslib_1.__awaiter(_this, void 0, void 0, function () {
        var error_2;
        return tslib_1.__generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    if (!division || !fromDate || !uptoDate) {
                        alert("All fields are required");
                        return [2 /*return*/];
                    }
                    _a.label = 1;
                case 1:
                    _a.trys.push([1, 4, , 5]);
                    return [4 /*yield*/, DataUploadWebPart_1.sp.web.lists
                            .getByTitle("PerformerClosureAccess")
                            .items.add({
                            Title: division + " - " + fromDate,
                            FinancialYear: division,
                            Month: fromDate,
                            DateofClosure: uptoDate
                        })];
                case 2:
                    _a.sent();
                    alert("Saved successfully ✅");
                    // reset
                    setDivision("");
                    setFromDate("");
                    setUptoDate("");
                    // reload table
                    return [4 /*yield*/, getHistoryData()];
                case 3:
                    // reload table
                    _a.sent();
                    return [3 /*break*/, 5];
                case 4:
                    error_2 = _a.sent();
                    console.log(error_2);
                    alert("Error saving data");
                    return [3 /*break*/, 5];
                case 5: return [2 /*return*/];
            }
        });
    }); };
    var th = {
        border: "1px solid #ccc",
        padding: "8px",
        textAlign: "center"
    };
    var td = {
        border: "1px solid #ccc",
        padding: "8px",
        textAlign: "center"
    };
    var handlePageChange = function (page) {
        if (page >= 1 && page <= totalPages) {
            setCurrentPage(page);
        }
    };
    var sortedData = tslib_1.__spreadArray([], filteredData, true).sort(function (a, b) { return b.ID - a.ID; });
    var paginatedData = sortedData.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage);
    return (React.createElement("div", null,
        React.createElement("div", { className: 'header' },
            React.createElement("h1", null, "Performer Closure Access")),
        React.createElement("div", { className: "PaddAll" },
            React.createElement("div", { className: 'row mb-20' },
                React.createElement("div", { className: 'col-md-4' },
                    React.createElement("label", { htmlFor: "Financial Year", className: 'font' }, "Financial Year"),
                    React.createElement("select", { value: division, className: "form-control", onChange: function (e) { return setDivision(e.target.value); } },
                        React.createElement("option", { value: "" }, "Select Year"),
                        getFinancialYears().map(function (yr) { return (React.createElement("option", { key: yr, value: yr }, yr)); }))),
                React.createElement("div", { className: 'col-md-4' },
                    React.createElement("label", { htmlFor: "Month", className: 'font' }, "Month"),
                    React.createElement("select", { value: fromDate, className: "form-control", onChange: function (e) { return setFromDate(e.target.value); } },
                        React.createElement("option", { value: "" }, "Select Month"),
                        ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"]
                            .map(function (m) { return React.createElement("option", { key: m, value: m }, m); }))),
                React.createElement("div", { className: 'col-md-4' },
                    React.createElement("label", { htmlFor: "Employee Email", className: 'font' }, "Date of Closing"),
                    React.createElement("input", { type: "date", className: "form-control", value: uptoDate, onChange: function (e) { return setUptoDate(e.target.value); } }))),
            React.createElement("div", { className: "row mb-20" },
                React.createElement("div", { className: "col-md-12", style: { margin: "10px", textAlign: "end" } },
                    React.createElement("button", { className: "submit-btn", onClick: handleSave }, " Save "))),
            React.createElement("hr", { style: { marginTop: "30px" } }),
            React.createElement("div", { className: "heading1" },
                React.createElement("label", null, "History Info")),
            React.createElement("div", { className: 'main-formcontainer' },
                React.createElement("div", { className: "overflow-x-auto" },
                    React.createElement("div", { className: "table-vert-scroll" },
                        React.createElement("table", { className: "custom-table min-w-full bg-white rounded-2xl shadow-md" },
                            React.createElement("thead", { style: { backgroundColor: "#3c3e45" }, className: "text-white" },
                                React.createElement("tr", null,
                                    React.createElement("th", { className: "px-4 py-2" }, "S.No"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Financial Year"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Month"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Closing Date"),
                                    React.createElement("th", { className: "px-4 py-2" }, "Created By"),
                                    React.createElement("th", { style: th }, "Created On"))),
                            React.createElement("tbody", null, paginatedData.map(function (item, index) { return (React.createElement("tr", { key: index, className: "border-t" },
                                React.createElement("td", { className: "px-4 py-2" }, index + 1),
                                React.createElement("td", { className: "px-4 py-2" }, item.FinancialYear),
                                React.createElement("td", { className: "px-4 py-2" }, item.Month),
                                React.createElement("td", { className: "px-4 py-2" }, item.DateofClosure),
                                React.createElement("td", { className: "px-4 py-2" }, item.CreatedBy),
                                React.createElement("td", { className: "px-4 py-2" }, item.CreatedOn))); })))),
                    React.createElement("div", { className: "flex justify-center mt-6 overflow-x-auto" },
                        React.createElement("div", { className: "flex space-x-2 flex-nowrap px-4 py-2 bg-#2149d5 rounded shadow", style: { textAlign: "end" } },
                            React.createElement("button", { onClick: function () { return handlePageChange(currentPage - 1); }, disabled: currentPage === 1, style: {
                                    backgroundColor: "#fff",
                                    border: "1px solid #000 !important",
                                    marginRight: "5px",
                                    opacity: currentPage === 1 ? 0.5 : 1,
                                }, className: "px-3 py-1 border rounded" },
                                React.createElement("img", { src: LeftArrow_png_1.default, alt: "", width: 15 })),
                            Array.from({ length: totalPages }, function (_, i) { return i + 1; })
                                .filter(function (page) { return Math.abs(page - currentPage) <= 2; })
                                .map(function (page) { return (React.createElement("button", { key: page, onClick: function () { return handlePageChange(page); }, style: {
                                    backgroundColor: currentPage === page ? "#3c3e45" : "#fff",
                                    color: currentPage === page ? "#fff" : "#000",
                                    fontWeight: currentPage === page ? "bold" : "normal",
                                    margin: currentPage === page ? "5px" : "5px",
                                }, className: "px-3 py-1 border rounded" }, page)); }),
                            React.createElement("button", { onClick: function () { return handlePageChange(currentPage + 1); }, disabled: currentPage === totalPages, style: {
                                    backgroundColor: "#fff",
                                    border: "1px solid #000 !important",
                                    marginLeft: "5px",
                                    opacity: currentPage === totalPages ? 0.5 : 1,
                                }, className: "px-3 py-1 border rounded" },
                                React.createElement("img", { src: RightArrow_png_1.default, alt: "", width: 15 })))))),
            React.createElement("div", { style: { textAlign: "center", marginTop: "10px" } },
                React.createElement("button", { onClick: handleExit, className: "Reject-btn" }, " Exit ")))));
}
//# sourceMappingURL=PerformerCloserAccess.js.map